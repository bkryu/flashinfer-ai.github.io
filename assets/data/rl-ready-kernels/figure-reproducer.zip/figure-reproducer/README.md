# Reproduce the current blog figures on CPU

FI denotes FlashInfer; BI denotes bitwise batch-invariant and non-BI denotes non-batch-invariant.

Requires Python, matplotlib, and numpy. No CUDA, FlashInfer installation, GPU, or new measurements are needed.

From this extracted directory, with each output directory initially absent:

    python plot_blog_performance.py --analysis analysis --out performance
    python plot_class_boundaries.py --data class-map --out boundaries
    python draw_rl_overview.py --out rl-overview
    python draw_batch_invariance.py --out batch-diagrams
    python draw_numerical_dataflow.py --out dataflow-diagrams
    python draw_canonical_dataflow.py --out canonical-diagram

The performance renderer writes BF16/NVFP4 overviews with separate untuned/autotuned rows, split-K retention bars and heatmap, ten full-latency figures, display-ratios.csv, and splitk-retention-cells.csv. BI names are bold and explicitly labeled; non-BI paths are labeled separately. Ratios in the main comparisons are comparator latency / FI BI latency. Split-K retention is policy latency / forced-unsplit latency, so values below one show the performance lost when removing splitting. The original latency.csv paired_speedup column retains its original reciprocal definition.

analysis/summary.json and analysis/latency.csv are unchanged frozen analysis inputs. class-map/ contains the unchanged saved class-policy evaluations; the new boundary-only rendering has no benchmark-shape markers. Input hashes and source hashes accompany the scripts. The original raw-measurement archive supplies kernel/harness snapshots, samples, correctness checks, and original rendering sources. Earlier figure versions remain in the workspace archives.


The current figures show selected comparisons while retaining all original measurements in the frozen inputs. The split-K figures evaluate a hypothetical no-split policy with actual kernel timings. The numerical-class diagram uses continuous elbow connectors.

The displayed split-K study now uses seven shapes, excluding N=128,K=65536 from both the heatmap and aggregate bars. The full eight-shape sweep remains in the CSV; included_in_displayed_study marks the 140 displayed and 20 retained-but-omitted cells. The same subset is used for all formats and tuning modes.

Display labels are Low-Concurrency Decode (M ≤ 16), High-Concurrency Decode (16 < M < 1024), and Prefill (M ≥ 1024). Original decode/middle/prefill machine-readable keys are preserved; display-ratios.csv includes regime_label. These shape ranges are representative rather than exclusive serving-phase definitions. The batch diagrams pair hexadecimal BF16 bits with decimal values, and the reduction-tree diagram places the FP32 rounding explanation beside the rounded intermediate.

The RL overview is a schematic, not measured data. It follows the same colored token identities from changing rollout batches into a regrouped training microbatch. Its log-probability equality is the target for the full pipeline at matching policy weights and histories; consistent GEMMs are one building block toward that target. The palette matches the subsequent GEMM diagrams. `rl-overview-render-manifest.json` records the source and asset hashes.

All 23 published figures use 50% larger text than the original article figures via figure_typography.py. Layouts accommodate the enlarged labels; plotted values and frozen inputs are unchanged. typography-manifest.json records the common scale and rendered SVG hashes. All current diagrams, including the canonical dataflow, are reproduced by this bundle. The boundary renderer's class-regions.svg is published as class-regions-boundaries.svg.
