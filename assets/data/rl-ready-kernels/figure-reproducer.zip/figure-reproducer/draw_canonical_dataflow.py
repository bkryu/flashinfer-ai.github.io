"""Reproduce the canonical-dataflow diagram on CPU, without running analysis."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from figure_typography import enlarge_fonts

matplotlib.rcParams.update({
    "font.family": "DejaVu Sans", "svg.fonttype": "none",
    "svg.hashsalt": "flashinfer-canonical-dataflow", "savefig.facecolor": "white",
})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    fig, axis = plt.subplots(figsize=(12, 4.5))
    axis.set(xlim=(0, 12), ylim=(0, 4))
    axis.axis("off")
    boxes = [
        (.2, 2.3, 3.1, 1.4, "Numerical specification\nMMA steps · scales\nreduction order\nrounding points", "#edf4e4"),
        (4.4, 2.3, 3.1, 1.4, "Canonical reduction\nengine\nOrdered plan and\nsymbolic expressions", "#edf4e4"),
        (8.6, 2.3, 3.1, 1.4, "GPU kernel\nTile · cluster · raster\nplacement choices", "#edf4e4"),
        (4.4, .15, 3.1, 1.4, "Lean\nDataflow identities\nand configuration\nconstraints", "#edf2f8"),
        (8.6, .15, 3.1, 1.4, "Bitwise GPU tests\nImplementation\nagreement\nhardware assumptions", "#edf2f8"),
    ]
    for x, y, w, h, label, color in boxes:
        axis.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=.06",
                                      facecolor=color, edgecolor="#697568"))
        axis.text(x + w / 2, y + h / 2, label, ha="center", va="center",
                  fontsize=11, linespacing=1.4)
    for start, end in [((3.4, 3.0), (4.3, 3.0)), ((7.6, 3.0), (8.5, 3.0)),
                       ((5.95, 2.2), (5.95, 1.65)), ((10.15, 2.2), (10.15, 1.65))]:
        axis.annotate("", xy=end, xytext=start,
                      arrowprops={"arrowstyle": "->", "color": "#53624c", "lw": 1.6})
    axis.text(.2, .2, "Fix the numerical\ndataflow.\nOptimize its\nexecution.",
              fontsize=13, weight="bold", color="#426900")
    enlarge_fonts(fig)
    fig.tight_layout()
    for ext in ("svg", "png"):
        path = args.out / ("canonical-dataflow." + ext)
        fig.savefig(path, bbox_inches="tight", dpi=170,
                    metadata={"Date": None} if ext == "svg" else None)
        if ext == "svg":
            path.write_text("\n".join(s.rstrip() for s in path.read_text().splitlines()) + "\n")
    plt.close(fig)
    print("Wrote canonical-dataflow SVG and PNG to", args.out)


if __name__ == "__main__":
    main()
