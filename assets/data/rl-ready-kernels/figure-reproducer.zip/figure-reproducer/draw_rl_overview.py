"""Draw a CPU-only overview of rollout/trainer numerical agreement for RL."""
import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_typography import enlarge_fonts
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle
from matplotlib.path import Path as DrawPath

matplotlib.rcParams.update({
    "font.family": "DejaVu Sans",
    "svg.fonttype": "none",
    "svg.hashsalt": "flashinfer-rl-overview",
    "savefig.facecolor": "white",
})

# Match the token/row identities in draw_batch_invariance.py.
ROW_COLORS = ("#2563eb", "#c77c0a", "#8656c6", "#078478")
ROW_FILLS = ("#e5edfc", "#fff0d7", "#eee5f9", "#dcf2eb")
INK = "#24312b"
MUTED = "#617069"
BORDER = "#c6d0c2"
ROLLOUT_BATCHES = ((0, 1), (2,), (3,))
TRAINER_ROWS = (2, 0, 3, 1)


def box(ax, x, y, w, h, fill="white", edge=BORDER):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=.055",
        facecolor=fill, edgecolor=edge, linewidth=1.0,
    ))


def arrow(ax, start, end, via=()):
    points = (start, *via, end)
    path = DrawPath(points, [DrawPath.MOVETO] + [DrawPath.LINETO] * (len(points) - 1))
    ax.add_patch(FancyArrowPatch(
        path=path, arrowstyle="-|>", mutation_scale=15,
        linewidth=1.25, color="#879680", shrinkA=0, shrinkB=0,
    ))


def token_row(ax, x, y, w, h, token):
    ax.add_patch(Rectangle(
        (x, y), w, h, facecolor=ROW_FILLS[token],
        edgecolor=ROW_COLORS[token], linewidth=.8,
    ))
    ax.add_patch(Rectangle(
        (x, y), .055, h, facecolor=ROW_COLORS[token], edgecolor="none",
    ))
    ax.text(x + w / 2, y + h / 2, f"token {token}",
            ha="center", va="center", fontsize=11, color=ROW_COLORS[token])


def overview(out):
    fig, ax = plt.subplots(figsize=(13, 8.15))
    ax.set(xlim=(0, 13), ylim=(0, 8.55))
    ax.axis("off")
    fig.subplots_adjust(left=.015, right=.985, top=.99, bottom=.015)

    ax.text(.4, 8.12, "One Policy, Two Execution Patterns",
            fontsize=20, weight="bold", color=INK)
    ax.text(.4, 7.69, "RL generates tokens, then re-scores them for training.",
            fontsize=13, color=MUTED)

    box(ax, 2.15, 6.72, 8.7, .60, fill="#f1f4ee")
    ax.text(6.5, 7.02, "Same policy weights and token histories",
            ha="center", va="center", fontsize=13.5, color=INK)

    for center in (2.95, 10.05):
        arrow(ax, (6.5, 6.66), (center, 5.98),
              via=((6.5, 6.38), (center, 6.38)))

    box(ax, .45, 2.25, 5.0, 3.65)
    box(ax, 7.55, 2.25, 5.0, 3.65)
    ax.text(2.95, 5.46, "Rollout Engine", ha="center", fontsize=16,
            weight="bold", color=INK)
    ax.text(2.95, 5.06, "Generate with changing serving batches",
            ha="center", fontsize=11.5, color=MUTED)
    ax.text(10.05, 5.46, "Trainer", ha="center", fontsize=16,
            weight="bold", color=INK)
    ax.text(10.05, 5.06, "Re-score the same sampled tokens",
            ha="center", fontsize=11.5, color=MUTED)

    for i, (x, batch) in enumerate(zip((.92, 2.46, 4.0), ROLLOUT_BATCHES), 1):
        ax.text(x + .525, 4.55, f"Batch {i}", ha="center", fontsize=10.8, color=MUTED)
        for row, token in enumerate(batch):
            token_row(ax, x, 4.0 - row * .48, 1.05, .40, token)

    ax.text(10.05, 4.55, "Regrouped microbatch", ha="center", fontsize=10.8, color=MUTED)
    for row, token in enumerate(TRAINER_ROWS):
        token_row(ax, 8.5, 4.10 - row * .28, 3.1, .245, token)

    arrow(ax, (5.55, 4.08), (7.43, 4.08))
    ax.text(6.49, 4.57, "Same sampled\ntokens", ha="center", va="center",
            fontsize=10.8, color=MUTED, linespacing=1.35)
    ax.plot((6.5, 6.5), (4.08, 3.77), linestyle=":", color="#b99b68", linewidth=1)
    box(ax, 5.62, 2.85, 1.76, .96, fill="#fff7e9", edge="#e2cfac")
    ax.text(6.5, 3.33, "Batching may\nchange GPU\narithmetic",
            ha="center", va="center", fontsize=10.4, color="#926318", linespacing=1.15)

    for center, label, symbol in (
        (2.95, "Recorded log probabilities", "logp_rollout"),
        (10.05, "Recomputed log probabilities", "logp_train"),
    ):
        box(ax, center - 1.95, 2.5, 3.9, .62, fill="#f6f8f4")
        ax.text(center, 2.94, label, ha="center", va="center", fontsize=10.5, color=MUTED)
        ax.text(center, 2.66, symbol, ha="center", va="center", fontsize=13,
                fontfamily="DejaVu Sans Mono", color=INK)

    arrow(ax, (2.95, 2.18), (4.15, 1.82))
    arrow(ax, (10.05, 2.18), (8.85, 1.82))
    box(ax, 1.1, .72, 10.8, 1.05, fill="#edf5e8", edge="#cbdac0")
    ax.text(6.5, 1.47, "Desired Agreement Before a Policy Update",
            ha="center", va="center", fontsize=12.5, weight="bold", color="#365c20")
    ax.text(6.5, 1.03, "logp_rollout = logp_train",
            ha="center", va="center", fontsize=16, color="#365c20",
            fontfamily="DejaVu Sans Mono")
    ax.text(6.5, .22, "Colors track the same token rows across both execution paths.",
            ha="center", fontsize=10.5, color=MUTED)

    enlarge_fonts(fig)
    for ext in ("svg", "png"):
        path = out / f"rl-rollout-trainer.{ext}"
        fig.savefig(path, bbox_inches="tight", dpi=170, pad_inches=.18,
                    metadata={"Date": None} if ext == "svg" else None)
        if ext == "svg":
            path.write_text("\n".join(line.rstrip() for line in path.read_text().splitlines()) + "\n")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    # The diagram rearranges the selected token rows without losing or duplicating them.
    assert sorted(token for batch in ROLLOUT_BATCHES for token in batch) == sorted(TRAINER_ROWS)
    overview(args.out)
    print(f"Wrote RL overview SVG and PNG to {args.out}")


if __name__ == "__main__":
    main()
