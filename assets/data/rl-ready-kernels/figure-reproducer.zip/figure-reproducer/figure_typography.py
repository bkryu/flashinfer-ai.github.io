"""Shared, presentation-only typography for the RL article's CPU renderers."""
from matplotlib.text import Text

FONT_SCALE = 1.50


def enlarge_fonts(fig):
    """Increase every text artist once, including ticks and legend labels."""
    if getattr(fig, "_rl_fonts_enlarged", False):
        return
    fig.canvas.draw()
    for artist in fig.findobj(match=Text):
        artist.set_fontsize(artist.get_fontsize() * FONT_SCALE)
    fig._rl_fonts_enlarged = True
