# FlashInfer RL-readiness article and GEMM study

Author: Brian K. Ryu. Hardware name for prose and figures: **NVIDIA Vera Rubin NVL4** (SM107).

The article draft is `2026-11-11-rl-ready-kernels.md`. It follows the website's Jekyll post front matter and technical-article layout. It is a review draft; publication remains manual. The text also explains why switching between Ampere-style warp-level MMA and `tcgen05` can change numerics on the same GPU.

For local reading, the draft uses native Markdown images with relative PNG paths. `preview.html` embeds every figure so it also works as a standalone offline reading copy. Regenerate it with `prepare_review.py` after `update_draft_results.py`; SVG originals remain alongside the PNGs. `prepare_site_branch.py` writes the website post with root-relative SVG links and a separate GitHub-readable `scripts/rl-readiness/README.md` with relative PNG links. This keeps review and publication paths explicit.

All performance tables include a **Batch Invariant** Yes/No column for the selected comparator mode. FI's invariant control is Yes throughout; the forced-unsplit ablation is also independently invariant. Flags describe the validated mode, not incidental equality in a regular backend. The measured BF16 decode/middle aggregates favor FI over every BI comparator, while DeepGEMM prefill is near parity; no universal all-regime win is claimed.

## Scope

- BF16: FlashInfer invariant GEMM; FI regular CUTLASS, cuDNN, and cuTile; FI CuTe DSL at decode only (M <= 16); and separate PyTorch Inductor BI/Triton, vLLM persistent Triton BI, and DeepGEMM deterministic BF16 comparisons.
- NVFP4: FlashInfer invariant GEMM, FlashInfer regular CuTe DSL, and vLLM invariant CUTLASS W4A4.
- NVFP4 measures prequantized GEMM only. All implementations receive the same code bytes, E4M3 block scales, and alpha.
- Eight projection shapes, fourteen M values, plus separately labeled narrow-N/long-K diagnostics.
- Tinygemm is discussed only to explain tensor-core instruction changes; it is excluded from measurements.
- No cuBLAS performance results are publication inputs.
- Every comparator appears in untuned and autotuned studies. vLLM exposes a shape table (BF16) or fixed kernel (NVFP4), and native DeepGEMM BF16 uses a heuristic, with no runtime search; both studies state those selection methods.
- N/K maps cover the policy's unsplit and chunked classes. Paired BF16/NVFP4 ablations force C=1 on split-region shapes at the same MMA primitive, with independent invariant checks and both tuning modes.

`investigation.md` preserves the earlier broad investigation. The scope above and the latest user decisions govern this study.

## GPU admission

Every GPU command uses `with_idle_gpu.py`. It accepts only physical GPU 2 or 3, acquires the workspace's exclusive device lock, checks utilization/memory/processes three times, and sets `CUDA_VISIBLE_DEVICES` before launching the command. It refuses busy devices. GPUs 0 and 1 are never used by this campaign.

Example environment and launch:

```bash
source /home/scratch.bryu_gpu_2/flashinfer-rl/env.sh
TORCHINDUCTOR_CACHE_DIR="$R/.cache/blog-torch-inductor-static" \
TORCHINDUCTOR_BATCH_INVARIANT=1 TORCHINDUCTOR_DETERMINISTIC=0 \
PYTHONDONTWRITEBYTECODE=1 \
python -B blog/rl-readiness/with_idle_gpu.py --gpu 2 -- \
  python -B blog/rl-readiness/benchmark_gemm.py --dtype bf16 \
  --out blog/rl-readiness/results/bf16-static-primary
```

```bash
source /home/scratch.bryu_gpu_2/flashinfer-rl/env.sh
VLLM_BATCH_INVARIANT=1 MAX_JOBS=2 PYTHONDONTWRITEBYTECODE=1 \
python -B blog/rl-readiness/with_idle_gpu.py --gpu 3 -- \
  python -B blog/rl-readiness/benchmark_gemm.py --dtype nvfp4 \
  --out blog/rl-readiness/results/nvfp4-primary
```

Add `--diagnostics --fi-only --tokens 1,16,128,1024,8192` for the separate narrow-N/long-K FI sweep. Use a fresh output directory for each run. Existing samples and interrupted runs are preserved; the analyzer rejects incomplete or duplicate-length datasets. Compilation, data preparation, and correctness run before each timed case.

Use `bash blog/rl-readiness/run_study.sh --gpu 2 --study bf16-libraries --out <fresh-directory>` to collect both modes by default. The runner also supports `bf16-primary`, `bf16-extra`, `nvfp4`, and `splitk-bf16`. See [REPRODUCING.md](REPRODUCING.md) for exact-snapshot replay, dependencies, scope, and artifact validation.

## Backend provenance

The PyTorch comparison uses `batch_invariant=True`, `max_autotune=True`, Triton-only GEMM candidates, and no external ATen GEMM fallback. The separate deterministic option stays off so it does not disable normal GEMM autotuning. Publication runs specialize each shape (`dynamic=False`), save generated source and its hash, and reject generated external ATen matmul calls. They verify bitwise equality across M, repeat runs, boundary sizes, and row permutation.

The initial `bf16-primary` dataset used fully dynamic shapes. It is retained as a **dynamic-shape diagnostic**, not the primary publication baseline; use `bf16-static-primary` for the stronger per-shape PyTorch comparison. The first two PyTorch pilot directories likewise establish admission and are not performance results.

The final paired primary BF16 datasets are `bf16-untuned-v2` and `bf16-autotuned`. Supplemental pairs are `bf16-extra-{untuned,autotuned}` and `bf16-libraries-{untuned,autotuned}`. The earlier `bf16-static-primary` has untuned FI versus autotuned PyTorch and remains a useful cross-check, outside the final matched-mode summary. BF16 CuTe DSL's early M=32 observations stay raw but are excluded from every published figure, table, and aggregate.

`bf16-splitk-untuned` is an excluded diagnostic attempt: PyTorch's unprofiled option failed a bitwise check at N=128, K=8192, M=129 against M=8192. This lies outside the main eight-shape matrix. The dedicated `torch-narrow-bitwise-diagnostic` reproduced mismatches in both modes (63 unprofiled / 68 autotuned output elements for this seed); it preserves the follow-up and generated code. FI-only diagnostics isolate the fixed-chunk behavior without admitting a failed comparator.

The vLLM adapter in `vllm_fp4.py` compiles unchanged upstream `nvfp4_scaled_mm_kernels.cu` and adds only stable-ABI operator registration in `vllm_fp4_binding.cpp`. It uses vLLM's pinned CUTLASS v4.7.1 (`cb4247394dd82148787aed73e5dc7cef33cbf862`) and the workspace's CCCL headers. The resulting kernel remains the upstream persistent invariant W4A4 path selected by `VLLM_BATCH_INVARIANT=1`.

DeepGEMM's native BF16 entry uses `use_deterministic_algorithms(True)` and PDL disabled. The flag explicitly excludes its cuBLAS branch. Its pinned CUTLASS 4.2.1 also lacks native SM107 feature guards; the validated run uses compatible SM100-family compilation through a target-only compiler adapter. Source and heuristic are unchanged. See `build_deepgemm.sh`, the build manifest, generated sources, compiler invocation records, and per-dataset provenance. The inspected native FP4 path is MXFP4; its explicit NVFP4 API is cuBLAS-backed and is excluded.

CUTLASS v4.7.1 lacks native SM107 feature guards. The successful build uses the supported SM100-family compatibility target (`compute_100f`, `sm_100f`) on Vera Rubin. A native `107f` build triggered a feature-guard assertion in the pilot and is excluded. No numerical kernel source was patched. `vllm-fp4-build.json` records the CUDA source hash, adapter hash, commits, flags, and library path. This is a kernel-operation comparison, not an installed full vLLM engine comparison.

## Timing and validation

`benchmark_gemm.py` uses cold-L2 CUPTI tracing under CUDA graph replay. There are ten warmup iterations, fifty samples per round, and three rounds with shuffled backend order. The first-to-last kernel span includes any split-K fixup. The helper flushes 2x L2 before each measured operation, outside the measured span. CUPTI fallback is rejected.

All outputs are BF16. Small CPU FP64 product slices provide an accuracy check; invariance uses integer-view equality within each invariant backend. Cross-library bit equality is not required because numerical classes differ. The GPU's active clocks, temperature, power, memory, and utilization are recorded around every round; clocks are not locked. The shared venv has stale FlashInfer 0.7.3 build metadata, so the source commit and import path are recorded separately.

Raw per-iteration samples, three-round telemetry, and correctness records are in each dataset directory. `manifest.json` must contain `complete: true` before a dataset enters analysis. The run log records the GPU's idle admission samples.

cuDNN uses the explicitly named FI backend, with heuristic default selection or FI tactic profiling. cuTile uses its native GPU default or exhaustive search, with required output zeroing inside timing. An adapter retains identical cuTile kernel objects through CUDA graph capture/replay to avoid unloading a temporary launch object during capture. Its numerical source and configurations are unchanged. Native-binding shutdown diagnostics are retained in the logs.

Each dataset has the exact measured `harness.py` snapshot, whose SHA-256 must match its manifest. Later runs also capture package versions and compiler/driver details at launch. Untuned and autotuned datasets are separate. FlashInfer autotuned runs save `flashinfer-autotune.json` and assert that their invariant outputs match the direct untuned implementation. PyTorch's unprofiled mode uses its deterministic candidate selector (no GPU tactic profiling); its autotuned mode permits normal Triton candidate profiling. vLLM's invariant W4A4 configuration is fixed and has no separate search.

To replay an exact measured harness snapshot, choose a fresh output directory and launch through the same idle-device gate. For example:

```bash
source /home/scratch.bryu_gpu_2/flashinfer-rl/env.sh
VLLM_BATCH_INVARIANT=1 PYTHONDONTWRITEBYTECODE=1 \
python -B blog/rl-readiness/with_idle_gpu.py --gpu 3 -- \
  python -B blog/rl-readiness/reproduce.py \
  blog/rl-readiness/results/nvfp4-primary \
  --out blog/rl-readiness/results/nvfp4-reproduction
```

The reproducer checks source commits and snapshot hashes and restores the measured shape/token matrix. Fresh autotuning can select a different equivalent tactic under a different timing environment; archived tactic files preserve what the reported run selected.

## Figures and tables

Matplotlib is installed in `plot-deps/`, separate from the shared environment. To analyze complete publication datasets:

```bash
source /home/scratch.bryu_gpu_2/flashinfer-rl/env.sh
PYTHONPATH="$R/blog/rl-readiness/plot-deps" \
MPLCONFIGDIR="$R/.cache/blog-mpl" \
python -B blog/rl-readiness/analyze_results.py \
  blog/rl-readiness/results/bf16-static-primary \
  blog/rl-readiness/results/nvfp4-primary
```

The script emits `analysis/latency.csv`, `analysis/summary.json`, `analysis/results.md`, and standalone SVGs under `assets/imgs/rl-ready-kernels/`. Speedup means baseline latency divided by FlashInfer invariant latency. Regime aggregates give equal weight to each measured shape/M pair; a best-backend envelope is not used.

`site-reference/` is a read-only reference clone of the website. `cutlass-vllm/`, `plot-deps/`, compiled objects, and experimental/pilot data are development dependencies, not blog publication payloads.

## Final publication artifacts

`analysis-final/` selects fourteen complete primary/ablation datasets: 9,984 round records, 499,200 timing samples, and 4,416 successful recorded bitwise checks. Raw CuTe BF16 M=32 measurements are retained but excluded from article figures and aggregates. `publication-audit.json` records source/helper hashes, correctness, and dispersion. The first-round sensitivity audit changes no reported aggregate by more than 0.51%; no first-round observations were removed. High-compute BF16 five-round probes are archived separately as quality diagnostics.

`assets/data/rl-ready-kernels/flashinfer-rl-study.tar.gz` is generated by `package_reproducer.py analysis-final`. Timestamped originals remain under `bundles/`. The archive contains the post, measured snapshots, raw data, configuration files, generated code, logs, complete analysis, class maps, and reproduction instructions. `SHA256SUMS` verifies the download and the archive has internal file checksums. The website review branch is prepared separately; publication remains a manual step.
