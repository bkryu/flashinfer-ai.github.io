"""Show the measured cost of giving up chunking at fixed tensor-core primitive."""
import argparse
import csv
import json
import math
from pathlib import Path
import shutil

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np

HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("analysis",type=Path)
    args=parser.parse_args()
    data=json.loads((args.analysis/"summary.json").read_text())
    rows=list(csv.DictReader((args.analysis/"latency.csv").open()))
    fig,axes=plt.subplots(2,2,figsize=(13,9.5),sharex=True)
    norm=TwoSlopeNorm(vmin=-3,vcenter=0,vmax=3)
    for axis,(dtype,mode) in zip(axes.flat,[(d,m) for d in ("bf16","nvfp4") for m in ("untuned","autotuned")]):
        name=f"{dtype}-splitk-ablation-{mode}"
        manifest=data[name]["manifest"]
        shapes=[tuple(s) for s in manifest["shapes_nk"]]
        ms=manifest["tokens"]
        selected={(int(r["N"]),int(r["K"]),int(r["M"])):float(r["paired_speedup"])
                  for r in rows if r["dataset"]==name and r["backend"]=="flashinfer_unsplit_ablation"}
        ratios=np.array([[selected[n,k,m] for m in ms] for n,k in shapes])
        image=axis.imshow(np.log2(ratios),cmap="RdYlGn",norm=norm,aspect="auto")
        labels=[f"N={n}, K={k:,}, C={manifest['ablation_classes'][f'N={n},K={k}']['policy_chunks']}" for n,k in shapes]
        axis.set_yticks(range(len(shapes)),labels,fontsize=8)
        axis.set_xticks(range(len(ms)),[str(m) for m in ms])
        axis.tick_params(labelbottom=True)
        axis.set_title(f"{dtype.upper()} · {mode}")
        axis.set_xlabel("Token rows M")
        for i in range(len(shapes)):
            for j in range(len(ms)):
                axis.text(j,i,f"{ratios[i,j]:.2f}×",ha="center",va="center",fontsize=8,
                          color="white" if abs(math.log2(ratios[i,j]))>2 else "black")
    fig.suptitle("What does giving up split-K cost? · NVIDIA Vera Rubin NVL4\nForced-unsplit latency / policy-class latency · >1× favors the chunked policy",fontsize=13)
    fig.subplots_adjust(top=.88,bottom=.12,right=.87,left=.18,wspace=.7,hspace=.35)
    bar=fig.colorbar(image,ax=axes,fraction=.025,pad=.025,ticks=[-3,-2,-1,0,1,2,3])
    bar.ax.set_yticklabels(["0.125×","0.25×","0.5×","1×","2×","4×","8×"])
    fig.text(.02,.025,"Same operands, MMA primitive, epilogue, and profiling policy; different reduction classes.\nCold L2 · CUPTI · BF16 output · NVFP4 inputs prequantized · raw samples and absolute latencies archived.",fontsize=9)
    for ext in ("svg","png"):
        fig.savefig(args.analysis/f"splitk-ablation.{ext}",bbox_inches="tight",dpi=150)
    shutil.copyfile(args.analysis/"splitk-ablation.svg",HERE/"assets/imgs/rl-ready-kernels/splitk-ablation.svg")
    shutil.copyfile(args.analysis/"splitk-ablation.png",HERE/"assets/imgs/rl-ready-kernels/splitk-ablation.png")
    shutil.copyfile(__file__,args.analysis/"ablation_plot_script.py")
    plt.close(fig)


if __name__=="__main__":
    main()
