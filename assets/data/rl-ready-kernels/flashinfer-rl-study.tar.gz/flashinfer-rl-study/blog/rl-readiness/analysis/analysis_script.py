"""Build tables and standalone SVG figures from complete publication datasets."""

import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path
import statistics
import shutil
import hashlib
from datetime import datetime, timezone
from backend_metadata import batch_invariant_label, render_results

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = Path(__file__).resolve().parent
LABELS = {"flashinfer_bi": "FlashInfer invariant", "flashinfer_cutlass": "FlashInfer regular CUTLASS",
          "torch_inductor_bi_triton": "PyTorch Inductor/Triton invariant option",
          "flashinfer_cute_dsl": "FlashInfer regular CuTe DSL",
          "vllm_cutlass_bi_w4a4": "vLLM CUTLASS invariant W4A4"}
LABELS.update({"flashinfer_bf16_cute_dsl":"FlashInfer regular BF16 CuTe DSL", "vllm_triton_bi":"vLLM persistent Triton invariant"})
LABELS.update({"flashinfer_cudnn":"FlashInfer cuDNN", "flashinfer_cutile":"FlashInfer cuTile"})
LABELS["flashinfer_unsplit_ablation"]="FI forced unsplit (different numerical class)"
LABELS["deepgemm_bf16_bi"]="DeepGEMM deterministic BF16"
COLORS = {"flashinfer_bi": "#68a800", "flashinfer_cutlass": "#626872",
          "torch_inductor_bi_triton": "#2676af", "flashinfer_cute_dsl": "#626872",
          "vllm_cutlass_bi_w4a4": "#9869aa"}
COLORS.update({"flashinfer_bf16_cute_dsl":"#c48127", "vllm_triton_bi":"#9869aa"})
COLORS.update({"flashinfer_cudnn":"#b34e51", "flashinfer_cutile":"#2676af"})
COLORS["flashinfer_unsplit_ablation"]="#b34e51"
COLORS["deepgemm_bf16_bi"]="#8d5a37"


def gmean(values):
    return math.exp(statistics.mean(math.log(v) for v in values))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("datasets", type=Path, nargs="+")
    parser.add_argument("--out", type=Path, default=HERE / "analysis")
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True, parents=True)
    if (args.out / "summary.json").exists():
        archive = args.out / "versions" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        archive.mkdir(parents=True)
        for file in args.out.iterdir():
            if file.is_file():
                shutil.copyfile(file, archive / file.name)
    shutil.copyfile(__file__, args.out / "analysis_script.py")
    assets = HERE / "assets/imgs/rl-ready-kernels"
    assets.mkdir(exist_ok=True, parents=True)
    fig, axis = plt.subplots(figsize=(12, 4))
    axis.set(xlim=(0, 12), ylim=(0, 4))
    axis.axis("off")
    boxes = [(0.2,2.4,3.1,1.05,"Numerical specification\nMMA steps · reduction order\nscales · rounding points", "#edf4e4"),
             (4.4,2.4,3.1,1.05,"Canonical reduction engine\nOrdered plan and\nsymbolic expressions", "#edf4e4"),
             (8.6,2.4,3.1,1.05,"GPU kernel\nTile · cluster · raster\nplacement choices", "#edf4e4"),
             (4.4,.55,3.1,1.05,"Lean\nDataflow identities and\nconfiguration constraints", "#edf2f8"),
             (8.6,.55,3.1,1.05,"Bitwise GPU tests\nImplementation agreement\nhardware assumptions", "#edf2f8")]
    for x,y,w,h,label,color in boxes:
        axis.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=.06",facecolor=color,edgecolor="#697568"))
        axis.text(x+w/2,y+h/2,label,ha="center",va="center",fontsize=11,linespacing=1.4)
    for start,end in [((3.4,2.93),(4.3,2.93)),((7.6,2.93),(8.5,2.93)),
                      ((5.95,2.3),(5.95,1.7)),((10.15,2.3),(10.15,1.7))]:
        axis.annotate("",xy=end,xytext=start,arrowprops={"arrowstyle":"->","color":"#53624c","lw":1.6})
    axis.text(.2,.9,"Fix the numerical dataflow.\nOptimize its execution.",fontsize=13,weight="bold",color="#426900")
    fig.tight_layout()
    fig.savefig(assets/"canonical-dataflow.svg",bbox_inches="tight")
    fig.savefig(args.out/"canonical-dataflow.svg",bbox_inches="tight")
    fig.savefig(assets/"canonical-dataflow.png",bbox_inches="tight",dpi=160)
    plt.close(fig)
    records = []
    summary = {}
    for dataset in args.datasets:
        manifest = json.loads((dataset / "manifest.json").read_text())
        if not manifest.get("complete"):
            raise RuntimeError(f"Incomplete dataset: {dataset}")
        source_rows = [json.loads(line) for line in (dataset / "samples.jsonl").read_text().splitlines()]
        expected = len(manifest["shapes_nk"]) * len(manifest["tokens"]) * 3 * manifest["rounds"]
        if manifest.get("fi_only"):
            expected //= 3
        if manifest.get("splitk_ablation") or manifest.get("bf16_deepgemm"):
            expected = len(manifest["shapes_nk"])*len(manifest["tokens"])*2*manifest["rounds"]
        if manifest.get("bf16_extra"):
            limit = manifest.get("bf16_cute_comparison_max_m",32)
            expected = len(manifest["shapes_nk"]) * (2*len(manifest["tokens"])+sum(m<=limit for m in manifest["tokens"])) * manifest["rounds"]
        if len(source_rows) != expected:
            raise RuntimeError(f"Unexpected sample count: {dataset}: {len(source_rows)} != {expected}")
        correctness = [json.loads(line) for line in (dataset/"correctness.jsonl").read_text().splitlines()]
        if any(row.get("bitwise_equal") is False or row.get("relative_error",0) > .02 for row in correctness):
            raise RuntimeError(f"Correctness failure in {dataset}")
        groups = defaultdict(list)
        for row in source_rows:
            # Keep every raw observation; the article compares BF16 CuTe DSL
            # only at decode under the study's final reporting scope.
            if row["backend"] == "flashinfer_bf16_cute_dsl" and row["M"] > 16:
                continue
            groups[(row["backend"], row["M"], row["N"], row["K"])].append(row)
        medians = {}
        for (backend, m, n, k), rounds in groups.items():
            if sorted(r["round"] for r in rounds) != list(range(manifest["rounds"])):
                raise RuntimeError(f"Missing or duplicate rounds: {dataset} {backend,m,n,k}")
            if any(len(r["samples_ms"]) != manifest["repeat_iters"] for r in rounds):
                raise RuntimeError(f"Wrong repeat count: {dataset} {backend,m,n,k}")
            samples = [t * 1000 for r in rounds for t in r["samples_ms"]]
            latency = statistics.median(samples)
            medians[(backend, m, n, k)] = latency
            records.append({"dataset": dataset.name, "dtype": manifest["dtype"], "backend": backend,
                            "batch_invariant":batch_invariant_label(backend),
                            "fi_autotuned":manifest["fi_autotuned"],
                            "backend_selection_mode":rounds[0].get("selection_mode", "see manifest"),
                            "M": m, "N": n, "K": k, "median_us": latency,
                            "p25_us": statistics.quantiles(samples, n=4)[0],
                            "p75_us": statistics.quantiles(samples, n=4)[2],
                            "effective_tflops": 2*m*n*k / (latency * 1e6),
                            "round_spread": max(r["median_us"] for r in rounds) / min(r["median_us"] for r in rounds)})
        for row in records:
            if row["dataset"] == dataset.name:
                row["paired_fi_median_us"] = medians[("flashinfer_bi",row["M"],row["N"],row["K"])]
                row["paired_speedup"] = row["median_us"] / row["paired_fi_median_us"]
        baselines = sorted({r["backend"] for r in source_rows} - {"flashinfer_bi"})
        regimes = {"decode": [m for m in manifest["tokens"] if m <= 16],
                   "middle": [m for m in manifest["tokens"] if 16 < m < 1024],
                   "prefill": [m for m in manifest["tokens"] if m >= 1024]}
        stats = {}
        for backend in baselines:
            stats[backend] = {}
            for regime, ms in regimes.items():
                ratios = [medians[(backend,m,n,k)] / medians[("flashinfer_bi",m,n,k)]
                          for n,k in manifest["shapes_nk"] for m in ms if (backend,m,n,k) in medians]
                stats[backend][regime] = {"geomean_speedup": gmean(ratios) if ratios else None,
                                          "min": min(ratios) if ratios else None, "max": max(ratios) if ratios else None,
                                          "faster_cases": sum(v>1 for v in ratios), "cases":len(ratios)}
        summary[dataset.name] = {"manifest":manifest, "speedups":stats}
        summary[dataset.name]["backend_batch_invariant"]={
            b:batch_invariant_label(b) for b in ["flashinfer_bi",*baselines]}
        summary[dataset.name]["validation"] = {
            "records": len(source_rows), "correctness_records":len(correctness),
            "timing_samples":sum(len(r["samples_ms"]) for r in source_rows),
            "publication_exclusions":"BF16 CuTe DSL M > 16 retained raw, excluded from all figures and aggregates",
            "analysis_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        count = len(manifest["shapes_nk"])
        fig, axes = plt.subplots(math.ceil(count/2), 2, figsize=(12, 3*math.ceil(count/2)), squeeze=False)
        backends = ["flashinfer_bi", *baselines]
        for axis, (n,k) in zip(axes.flat, manifest["shapes_nk"]):
            for backend in backends:
                ms = sorted(m for m in manifest["tokens"] if (backend,m,n,k) in medians)
                axis.plot(ms, [medians[(backend,m,n,k)] for m in ms], marker="o", markersize=3,
                          label=LABELS[backend], color=COLORS[backend], linewidth=1.7)
            axis.set_xscale("log", base=2)
            axis.set_yscale("log")
            axis.axvline(16, linestyle=":", color="#aaa", linewidth=.8)
            axis.axvline(1024, linestyle=":", color="#aaa", linewidth=.8)
            axis.set_title(f"N={n:,}, K={k:,}", fontsize=11)
            axis.set_xlabel("Token rows M")
            axis.set_ylabel("GPU latency (µs)")
            axis.grid(alpha=.18, which="both")
        for axis in list(axes.flat)[count:]:
            axis.set_visible(False)
        handles, labels = axes.flat[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="lower center", ncol=1 if count < 4 else 3, fontsize=9)
        fi_mode = "FlashInfer autotuned" if manifest["fi_autotuned"] else "FlashInfer untuned"
        other_mode = "Policy chunks vs forced C=1; same MMA, different numerical class" if manifest.get("splitk_ablation") else (
            "DeepGEMM upstream deterministic heuristic" if manifest.get("bf16_deepgemm") else
            "vLLM fixed" if manifest["dtype"] == "nvfp4" else (
            "FI-only split-K diagnostic" if manifest.get("fi_only") else
            "vLLM upstream shape table" if manifest.get("bf16_extra") else
            ("cuDNN + cuTile " + ("autotuned" if manifest["fi_autotuned"] else "unprofiled defaults")
             if manifest.get("bf16_libraries") else
             ("PyTorch unprofiled" if (manifest.get("torch_options") or {}).get("deterministic") else "PyTorch autotuned"))))
        fig.suptitle(f"{manifest['dtype'].upper()} GEMM — NVIDIA Vera Rubin NVL4\n{fi_mode} · {other_mode}\nCold L2 · CUPTI · CUDA graph replay · BF16 output", fontsize=13)
        fig.tight_layout(rect=(0,.05,1,.92))
        fig.savefig(assets / f"{dataset.name}.svg", bbox_inches="tight")
        fig.savefig(args.out / f"{dataset.name}.svg", bbox_inches="tight")
        fig.savefig(args.out / f"{dataset.name}.png", bbox_inches="tight", dpi=110)
        fig.savefig(assets / f"{dataset.name}.png", bbox_inches="tight", dpi=110)
        plt.close(fig)
    with (args.out / "latency.csv").open("w", newline="") as f:
        writer=csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    report=render_results(summary,LABELS)
    (args.out / "results.md").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
