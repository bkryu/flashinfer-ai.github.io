"""Paired untuned/autotuned comparison figures, with explicit backend coverage."""
import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
from backend_metadata import batch_invariant_label

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
PAIRS = {
    "bf16": [("FI regular CUTLASS", "flashinfer_cutlass", "bf16-untuned-v2", "bf16-autotuned"),
             ("FI regular CuTe DSL *", "flashinfer_bf16_cute_dsl", "bf16-extra-untuned", "bf16-extra-autotuned"),
             ("FI cuDNN", "flashinfer_cudnn", "bf16-libraries-untuned", "bf16-libraries-autotuned"),
             ("FI cuTile", "flashinfer_cutile", "bf16-libraries-untuned", "bf16-libraries-autotuned"),
             ("PyTorch Inductor BI / Triton", "torch_inductor_bi_triton", "bf16-untuned-v2", "bf16-autotuned"),
             ("vLLM Triton BI †", "vllm_triton_bi", "bf16-extra-untuned", "bf16-extra-autotuned"),
             ("DeepGEMM deterministic †", "deepgemm_bf16_bi", "bf16-deepgemm-untuned", "bf16-deepgemm-autotuned")],
    "nvfp4": [("FI regular CuTe DSL", "flashinfer_cute_dsl", "nvfp4-primary", "nvfp4-autotuned"),
              ("vLLM invariant W4A4 †", "vllm_cutlass_bi_w4a4", "nvfp4-primary", "nvfp4-autotuned")],
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis", type=Path)
    args = parser.parse_args()
    data = json.loads((args.analysis / "summary.json").read_text())
    previous = list(args.analysis.glob("*-overview.*"))
    if previous:
        version = args.analysis / "versions" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        version.mkdir(parents=True)
        for path in previous:
            shutil.copyfile(path, version/path.name)
    shutil.copyfile(__file__, args.analysis/"overview_script.py")
    output_rows = []
    for dtype, pairs in PAIRS.items():
        if any(name not in data for _,_,u,t in pairs for name in (u,t)):
            raise RuntimeError(f"Both selection modes are required for every {dtype} comparator")
        fig, axes = plt.subplots(1,3,figsize=(14, 6.4 if dtype=="bf16" else 4.2),sharey=True)
        y = np.arange(len(pairs))
        for axis, regime in zip(axes,("decode","middle","prefill")):
            for mode,offset,color in [("untuned",-.18,"#61932b"),("autotuned",.18,"#2471a3")]:
                for index,(label,backend,u,t) in enumerate(pairs):
                    dataset = t if mode=="autotuned" else u
                    stats = data[dataset]["speedups"][backend][regime]
                    value = stats["geomean_speedup"]
                    output_rows.append({"dtype":dtype,"study_selection":mode,"comparator":backend,
                                        "batch_invariant":batch_invariant_label(backend),
                                        "regime":regime,"dataset":dataset,**stats})
                    if value is None:
                        axis.text(.57,index+offset,"N/A",va="center",fontsize=8,color="#777")
                        continue
                    axis.barh(index+offset,value,height=.32,color=color,label=f"{mode.capitalize()} study" if index==0 else None)
                    axis.text(value*1.05,index+offset,f"{value:.2f}×",va="center",fontsize=8)
            axis.axvline(1,color="#444",linestyle="--",lw=1)
            axis.set_xscale("log",base=2)
            axis.set_xlim((.5,32) if dtype=="bf16" else (.5,4))
            ticks = [.5,1,2,4,8,16,32] if dtype=="bf16" else [.5,1,2,4]
            axis.set_xticks(ticks,[f"{v:g}×" for v in ticks])
            axis.set_title({"decode":"Decode: M ≤ 16","middle":"Middle: 16 < M < 1024","prefill":"Prefill: M ≥ 1024"}[regime])
            axis.grid(axis="x",alpha=.2)
            axis.set_axisbelow(True)
            axis.set_xlabel("Comparator latency / FI invariant latency")
        axes[0].set_yticks(y,[p[0] for p in pairs])
        axes[0].invert_yaxis()
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(handles,labels,loc="lower center",ncol=2,bbox_to_anchor=(.57,.075))
        note = ("* BF16 CuTe DSL: decode comparison only (M ≤ 16).  "
                "† vLLM / DeepGEMM: same upstream table / heuristic in both studies.\n"
                "PyTorch untuned: deterministic candidate choice without profiling; tuned: Triton profiling."
                if dtype=="bf16" else
                "† vLLM uses the same fixed invariant kernel in both studies; no runtime search is exposed.")
        fig.text(.02,.015,note,fontsize=9,va="bottom")
        fig.suptitle(f"{dtype.upper()} GEMM · NVIDIA Vera Rubin NVL4\nEqual-case geometric means · cold L2 · CUPTI · BF16 output · >1× favors FI invariant",fontsize=13)
        fig.tight_layout(rect=(0,.17,1,.91))
        for ext in ("svg","png"):
            path=args.analysis/f"{dtype}-overview.{ext}"
            fig.savefig(path,bbox_inches="tight",dpi=140)
        shutil.copyfile(args.analysis/f"{dtype}-overview.svg",HERE/f"assets/imgs/rl-ready-kernels/{dtype}-overview.svg")
        shutil.copyfile(args.analysis/f"{dtype}-overview.png",HERE/f"assets/imgs/rl-ready-kernels/{dtype}-overview.png")
        plt.close(fig)
    with (args.analysis/"paired-overview.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(output_rows[0]))
        writer.writeheader()
        writer.writerows(output_rows)


if __name__=="__main__":
    main()
