"""Audit the publication data and exact snapshots independently of plot design."""
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import re
import statistics

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("analysis",type=Path)
    args=parser.parse_args()
    summary=json.loads((args.analysis/"summary.json").read_text())
    totals=Counter()
    largest_error=0
    spreads=[]
    datasets={}
    for name,data in summary.items():
        root=HERE/"results"/name
        manifest=json.loads((root/"manifest.json").read_text())
        assert manifest["complete"] and manifest["physical_gpu"] in ("2","3")
        assert manifest["compute_capability"]==[10,7]
        assert manifest["rounds"]==3 and manifest["repeat_iters"]==50
        assert sha(root/"harness.py")==manifest["harness_sha256"]
        for filename,expected in manifest.get("helper_sha256",{}).items():
            assert sha(root/filename)==expected,(name,filename)
        rows=[json.loads(line) for line in (root/"samples.jsonl").read_text().splitlines()]
        assert not any("cublas" in row["backend"].lower() for row in rows)
        assert not any("falling back" in str(row.get("warnings",[])).lower() for row in rows)
        checks=[json.loads(line) for line in (root/"correctness.jsonl").read_text().splitlines()]
        errors=[c["relative_error"] for c in checks if "relative_error" in c]
        assert max(errors)<=.02
        assert not any(c.get("bitwise_equal") is False for c in checks)
        largest_error=max(largest_error,max(errors))
        sources=root/"torch-source-manifest.json"
        if sources.exists():
            for source in json.loads(sources.read_text()):
                p=root/source["file"]
                assert sha(p)==source["sha256"]
                assert not re.search(r"extern_kernels\.(mm|addmm|bmm)\s*\(",p.read_text())
        totals["round_records"]+=len(rows)
        totals["timing_samples"]+=sum(len(r["samples_ms"]) for r in rows)
        totals["correctness_records"]+=len(checks)
        totals["bitwise_checks"]+=sum(c.get("bitwise_equal") is True for c in checks)
        by_case={}
        for row in rows:
            key=(row["backend"],row["M"],row["N"],row["K"])
            by_case.setdefault(key,[]).append(row["median_us"])
        for key,values in by_case.items():
            spreads.append({"dataset":name,"case":key,"ratio":max(values)/min(values)})
        datasets[name]={"records":len(rows),"harness_sha256":manifest["harness_sha256"],
                        "backends":dict(Counter(r["backend"] for r in rows))}
    values=sorted(r["ratio"] for r in spreads)
    report={"datasets":datasets,"totals":dict(totals),"largest_reference_slice_relative_error":largest_error,
            "round_median_spread":{"median":statistics.median(values),"p95":values[int(.95*(len(values)-1))],
                                   "max":max(values),"largest_cases":sorted(spreads,key=lambda r:r["ratio"],reverse=True)[:10]},
            "excluded_diagnostics":"Exploratory, incomplete and failed runs are preserved locally, outside this publication analysis.",
            "script_sha256":sha(Path(__file__))}
    (args.analysis/"publication-audit.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"totals":report["totals"],"max_relative_error":largest_error,
                      "round_spread":{k:v for k,v in report["round_median_spread"].items() if k!="largest_cases"}},indent=2))


if __name__=="__main__":
    main()
