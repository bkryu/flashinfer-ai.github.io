"""Retain published pooled medians; test sensitivity to omitting the first round."""
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path
import statistics

HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("analysis",type=Path)
    args=parser.parse_args()
    summary=json.loads((args.analysis/"summary.json").read_text())
    results=[]
    for name,data in summary.items():
        rows=[json.loads(s) for s in (HERE/"results"/name/"samples.jsonl").read_text().splitlines()]
        pooled=defaultdict(list)
        for r in rows:
            if r["round"]==0 or (r["backend"]=="flashinfer_bf16_cute_dsl" and r["M"]>16):
                continue
            pooled[r["backend"],r["M"],r["N"],r["K"]].extend(r["samples_ms"])
        medians={key:statistics.median(v) for key,v in pooled.items()}
        for backend,regimes in data["speedups"].items():
            for regime,stats in regimes.items():
                ratios=[]
                for (b,m,n,k),latency in medians.items():
                    actual="decode" if m<=16 else "middle" if m<1024 else "prefill"
                    if b==backend and actual==regime:
                        ratios.append(latency/medians["flashinfer_bi",m,n,k])
                if not ratios:
                    continue
                reduced=math.exp(statistics.mean(math.log(v) for v in ratios))
                full=stats["geomean_speedup"]
                results.append({"dataset":name,"backend":backend,"regime":regime,
                                "reported_all_rounds":full,"omit_round_zero":reduced,
                                "relative_change":reduced/full-1})
    report={"method":"Sensitivity only. Publication tables retain ALL three measured rounds; no observations removed.",
            "maximum_absolute_relative_change":max(abs(r["relative_change"]) for r in results),
            "comparisons":results}
    (args.analysis/"round-sensitivity.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"max_relative_change":report["maximum_absolute_relative_change"],
                      "largest":sorted(results,key=lambda r:abs(r["relative_change"]),reverse=True)[:5]},indent=2))


if __name__=="__main__":
    main()
