#!/usr/bin/env bash
# Build the pinned source locally; do not install into the shared Python env.
set -euo pipefail
study_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
workspace_dir=$(cd -- "$study_dir/../.." && pwd)
source_dir="$study_dir/deepgemm-source"
expected_commit=5081f8513af57e61696de4f4f04b0e707ffb503e
if [[ ! -d "$source_dir/.git" ]]; then
  git clone https://github.com/deepseek-ai/DeepGEMM.git "$source_dir"
  git -C "$source_dir" checkout --detach "$expected_commit"
fi
if [[ "$(git -C "$source_dir" rev-parse HEAD)" != "$expected_commit" ]]; then
  echo 'DeepGEMM checkout differs from the measured commit; use an isolated matching checkout.' >&2
  exit 2
fi
git -C "$source_dir" submodule update --init --depth 1
if [[ -f "$workspace_dir/env.sh" ]]; then source "$workspace_dir/env.sh"; fi
deps_dir="$study_dir/deepgemm-deps"
mkdir -p -- "$deps_dir/root" "$deps_dir/cuda-include" "$study_dir/logs"
if [[ ! -f "$deps_dir/root/usr/include/elfutils/libdwfl.h" ]]; then
  # Ubuntu 26.04 arm64 headers used by DeepJIT's optional exception backtraces.
  # Extract locally; no root privilege or system package changes.
  cd "$deps_dir"
  apt-get download libdw-dev=0.194-4 libelf-dev=0.194-4
  dpkg-deb --extract libdw-dev_0.194-4_arm64.deb root
  dpkg-deb --extract libelf-dev_0.194-4_arm64.deb root
fi
if [[ ! -e "$deps_dir/cuda-include/cccl" ]]; then
  ln -s "$workspace_dir/flashinfer/3rdparty/cccl/libcudacxx/include" "$deps_dir/cuda-include/cccl"
fi
export CUDA_VISIBLE_DEVICES='' TORCH_CUDA_ARCH_LIST=10.0 MAX_JOBS=2
export CPATH="$deps_dir/root/usr/include:$deps_dir/cuda-include:$workspace_dir/flashinfer/3rdparty/cccl/libcudacxx/include:$workspace_dir/flashinfer/3rdparty/cccl/cub:$workspace_dir/flashinfer/3rdparty/cccl/thrust"
cd "$source_dir"
python -B setup.py build
