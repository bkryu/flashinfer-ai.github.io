"""Evaluate the actual SM107 N/K class-selection policy without launching a GPU."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

os.environ["CUDA_VISIBLE_DEVICES"]=""
HERE=Path(__file__).resolve().parent
WORKSPACE=HERE.parents[1]
sys.path.insert(0,str(WORKSPACE/"flashinfer"))
from flashinfer.gemm.batch_invariant import schedule, spec

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm
import numpy as np

PRIMARY=[(4096,4096),(6144,4096),(14336,4096),(4096,14336),
         (8192,8192),(28672,8192),(8192,28672),(1024,28672)]
ABLATION=[(128,8192),(256,16384),(512,28672),(128,32768),
          (512,32768),(1024,32768),(2048,65536),(128,65536)]
FORMATS={"BF16":"bf16","FP8 E4M3":"e4m3","FP8 E5M2":"e5m2",
         "MXFP8":"mxfp8_k64","MXFP4":"mxfp4_k128","NVFP4":None}


def grid(lo,hi,granule):
    values={lo,hi}
    for i in range(math.ceil(math.log2(hi/lo)*24)+1):
        values.add(min(hi,max(lo,round(lo*2**(i/24)/granule)*granule)))
    return sorted(values)


def describe(n,k,format_name):
    fmt=FORMATS[format_name] or schedule.fp4_class_for(n,k,"sm_107")
    count=schedule.chunks_for(n,k,fmt)
    return {"format":format_name,"N":n,"K":k,"in_fmt":fmt,"chunks":count,
            "mma_k":spec.MMA_K_OF[fmt],"chunk_granule":spec.chunk_unit(fmt),
            "class_family":spec.class_name(fmt,count>1),"chunk_length":k/count}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--out",type=Path,default=HERE/"class-map")
    args=parser.parse_args()
    if args.out.exists():
        raise SystemExit("Choose a fresh class-map directory; previous maps are retained")
    args.out.mkdir(parents=True)
    ns=sorted(set(grid(32,32768,32))|{n for n,k in PRIMARY+ABLATION})
    ks=sorted(set(grid(256,524288,256))|{k for n,k in PRIMARY+ABLATION})
    rows=[describe(n,k,name) for name in FORMATS for k in ks for n in ns]
    with (args.out/"classes.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    selected=[describe(n,k,name) for name in FORMATS for n,k in ABLATION+PRIMARY]
    (args.out/"selected-shapes.json").write_text(json.dumps(selected,indent=2)+"\n")
    provenance={"architecture":"SM107", "gpu_launches":0,"N_grid":ns,"K_grid":ks,
        "flashinfer_commit":subprocess.check_output(["git","-C",str(WORKSPACE/"flashinfer"),"rev-parse","HEAD"],text=True).strip(),
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "sources":{p:hashlib.sha256((WORKSPACE/"flashinfer/flashinfer/gemm/batch_invariant"/p).read_bytes()).hexdigest()
                   for p in ("schedule.py","spec.py")},
        "notes":"Policy evaluation, not measured latency. Grid K values rounded to 256; other K granules can change class boundaries. Numerical class includes more than chunk count."}
    (args.out/"manifest.json").write_text(json.dumps(provenance,indent=2)+"\n")
    (args.out/"map_script.py").write_bytes(Path(__file__).read_bytes())
    fig,axes=plt.subplots(1,2,figsize=(13,5.5),sharey=True)
    cmap=plt.get_cmap("viridis",8)
    norm=BoundaryNorm(np.arange(-.5,8.5),8)
    for axis,name in zip(axes,("BF16","NVFP4")):
        values=np.array([[math.log2(describe(n,k,name)["chunks"]) for n in ns] for k in ks])
        mesh=axis.pcolormesh(ns,ks,values,cmap=cmap,norm=norm,shading="nearest",rasterized=True)
        axis.scatter(*zip(*PRIMARY),marker="o",facecolors="none",edgecolors="#ef6c00",s=45,label="Primary shapes",zorder=3)
        axis.scatter(*zip(*ABLATION),marker="x",color="#e02929",s=40,label="Ablation shapes",zorder=3)
        axis.set_xscale("log",base=2); axis.set_yscale("log",base=2)
        axis.set_xlabel("Output dimension N"); axis.set_title(name)
        axis.set_xticks([32,128,512,2048,8192,32768],["32","128","512","2K","8K","32K"])
        axis.set_yticks([256,1024,4096,16384,65536,262144],["256","1K","4K","16K","64K","256K"])
        axis.grid(alpha=.15)
        axis.set_xlim(32,32768); axis.set_ylim(256,524288)
    axes[0].set_ylabel("Reduction dimension K")
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="lower center",ncol=2,bbox_to_anchor=(.45,.045))
    fig.colorbar(mesh,ax=axes,ticks=range(8),label="Policy-selected chunk count C",fraction=.025,pad=.025).ax.set_yticklabels(["1 (unsplit)","2","4","8","16","32","64","128"])
    fig.suptitle("N/K numerical-class regions · FlashInfer on SM107\nPolicy evaluation on aligned dimensions; independent of token count M",fontsize=13)
    fig.text(.03,.01,"NVFP4: unsplit regions use K=128-wide MMA; split regions use K=64-wide MMA. Exact boundaries also depend on divisibility.",fontsize=9)
    fig.subplots_adjust(top=.81,bottom=.22,right=.86,wspace=.12)
    for ext in ("svg","png"):
        fig.savefig(args.out/f"class-regions.{ext}",bbox_inches="tight",dpi=160)
    plt.close(fig)
    assets=HERE/"assets/imgs/rl-ready-kernels"
    (assets/"class-regions.svg").write_bytes((args.out/"class-regions.svg").read_bytes())
    print(json.dumps({"rows":len(rows),"out":str(args.out),"GPU_launches":0}))


if __name__=="__main__":
    main()
