"""Load the isolated upstream build; deterministic flag excludes cuBLAS dispatch."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import shutil

HERE=Path(__file__).resolve().parent
WORKSPACE=HERE.parents[1]


def load(out):
    root=HERE/"deepgemm-source"
    builds=list(root.glob("build/lib.*/deep_gemm/_C*.so"))
    if len(builds)!=1:
        raise RuntimeError("Build the pinned DeepGEMM extension in isolation first")
    sys.path.insert(0,str(builds[0].parents[1]))
    os.environ.setdefault("DG_JIT_NVCC_COMPILER",str(HERE/"deepgemm_nvcc_compat.py"))
    os.environ.setdefault("DG_COMPAT_COMPILE_LOG",str(out.resolve()/"deepgemm-compiler-invocations.jsonl"))
    os.environ.setdefault("DG_JIT_CACHE_DIR",str(WORKSPACE/".cache/blog-deepgemm-compat100f"))
    os.environ.setdefault("DG_JIT_PRINT_COMPILER_COMMAND","1")
    cccl=WORKSPACE/"flashinfer/3rdparty/cccl"
    includes=[HERE/"deepgemm-deps/cuda-include",cccl/"libcudacxx/include",cccl/"cub",cccl/"thrust"]
    os.environ["CPATH"]=os.pathsep.join([*(str(p) for p in includes),os.environ.get("CPATH","")])
    module=importlib.import_module("deep_gemm")
    module.use_deterministic_algorithms(True)
    module.set_pdl(False)
    provenance={"commits":{name:subprocess.check_output(["git","-C",str(path),"rev-parse","HEAD"],text=True).strip()
                for name,path in [("deepgemm",root),("cutlass",root/"third-party/cutlass"),("deepjit",root/"third-party/deep_jit")]},
        "module":module.__file__,"extension_sha256":hashlib.sha256(builds[0].read_bytes()).hexdigest(),
        "deterministic":True,"pdl":False,"entry":"bf16_gemm_nt", "compiled_dims":"nk",
        "selection":"Upstream heuristic; no native BF16 runtime autotuning interface",
        "jit_cache":os.environ["DG_JIT_CACHE_DIR"],
        "jit_compiler":os.environ.get("DG_JIT_NVCC_COMPILER",str(Path(os.environ["CUDA_HOME"])/"bin/nvcc")),
        "actual_compile_target":"sm_100f compatibility; native sm_107f fails pinned CUTLASS TMA feature guards",
        "cublas_exclusion":"csrc/apis/gemm.hpp admits cuBLAS only when deterministic_algorithms is false",
        "api_sha256":hashlib.sha256((root/"csrc/apis/gemm.hpp").read_bytes()).hexdigest()}
    (out/"deepgemm-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")

    def mm(a,b,output):
        # b is the original contiguous (N,K) weight, preserving the shared
        # row-major activations / column-major mathematical weight layout.
        module.bf16_gemm_nt(a,b,output,compiled_dims="nk")
        return output
    return mm


def archive_jit(out):
    inventory=[]
    target=out/"deepgemm-generated"
    target.mkdir(exist_ok=True)
    for source in sorted(Path(os.environ["DG_JIT_CACHE_DIR"]).rglob("kernel.cu")):
        digest=hashlib.sha256(source.read_bytes()).hexdigest()
        shutil.copyfile(source,target/f"{digest}.cu")
        cubin=source.with_name("kernel.cubin")
        inventory.append({"source_sha256":digest,"source":str(source),
                          "cubin_sha256":hashlib.sha256(cubin.read_bytes()).hexdigest() if cubin.exists() else None})
    (out/"deepgemm-jit-inventory.json").write_text(json.dumps(inventory,indent=2)+"\n")
