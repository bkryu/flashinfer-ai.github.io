#!/usr/bin/env python3
"""Compile unchanged DeepGEMM/CUTLASS kernels for the compatible SM100 family.

CUTLASS 4.2.1 lacks the native SM107 feature guards. This wrapper is selected
through DeepJIT's DG_JIT_NVCC_COMPILER option, and only rewrites the target.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

requested=sys.argv[1:]
actual=["--gpu-architecture=sm_100f" if a=="--gpu-architecture=sm_107f" else a for a in requested]
if "--cubin" in requested:
    with Path(os.environ["DG_COMPAT_COMPILE_LOG"]).open("a") as f:
        f.write(json.dumps({"utc":datetime.now(timezone.utc).isoformat(),
                            "requested":requested,"actual":actual})+"\n")
nvcc=Path(os.environ["CUDA_HOME"])/"bin/nvcc"
os.execv(str(nvcc),[str(nvcc),*actual])
