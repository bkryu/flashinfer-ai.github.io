
#include <deep_gemm/impls/sm100_bf16_gemm.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm100_bf16_gemm_impl<
        cute::UMMA::Major::K, cute::UMMA::Major::K,
        0, 128, 8192,
        128, 16, 64,
        1,
        128, 128, 32,
        12,
        128, 128,
        1, false,
        212,
        128,
        0, true,
        GemmType::Normal, false, cutlass::bfloat16_t,
        epilogue::operators::Identity,
        100
    >);
};
