"""Five-round quality check on two high-compute BF16 shapes."""
from pathlib import Path
import runpy
import shutil
import sys

HERE=Path(__file__).resolve().parent
mode,out=sys.argv[1:]
if mode not in ("fi","deepgemm"):
    raise SystemExit("Choose fi or deepgemm")
ns=runpy.run_path(str(HERE/"benchmark_gemm.py"),run_name="stability_harness")
fn=ns["main"]
fn.__globals__["SHAPES"]=[(8192,8192),(8192,28672)]
sys.argv=[str(HERE/"benchmark_gemm.py"),"--dtype","bf16","--out",out,
          "--fi-tune","--tokens","1024,8192","--rounds","5",
          "--fi-only" if mode=="fi" else "--bf16-deepgemm"]
fn()
shutil.copyfile(__file__,Path(out)/"launch_script.py")
