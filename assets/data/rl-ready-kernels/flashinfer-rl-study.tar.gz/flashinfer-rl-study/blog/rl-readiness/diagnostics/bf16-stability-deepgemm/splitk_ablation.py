"""Use FI's unchanged invariant runner with an explicit, fixed chunk count.

This is a numerical-class ablation, not an equivalent tactic of the default
chunked class. The tensor-core primitive and epilogue remain fixed within each
pair. In particular NVFP4 split-region pairs both use its 64-wide MMA class.
"""
from flashinfer.autotuner import AutoTuner
from flashinfer.gemm.batch_invariant import api, tuning


def unsplit(dtype, a, b, output, *, sfa=None, sfb=None, alpha=None):
    if dtype == "bf16":
        fmt = "bf16"
        name = "mm_bf16"
        inputs = [a, b, output, None]
        config, op = tuning.TUNING_CONFIG, tuning.CUSTOM_OP
    else:
        # Resolve from the ORIGINAL weight shape, before overriding C. Thus
        # disabling chunks does not also switch Rubin's instruction primitive.
        fmt = api.fp4_format_for(a.device, True, b.shape[1], 2*a.shape[1], None)
        name = "mm_fp4"
        inputs = [a, b, sfa, sfb, alpha, output]
        config, op = tuning.TUNING_CONFIG_MM_FP4["nvfp4"], tuning.CUSTOM_OP_MM_FP4
    runner = tuning._runner(name, fmt, "k", 1, *api.part_of(a.device))
    chosen, tactic = AutoTuner.get().choose_one(op, [runner], config, inputs)
    chosen(inputs=inputs, tactic=tactic)
    return output


def untuned_unsplit(dtype, a, b, output, *, sfa=None, sfb=None, alpha=None):
    if dtype == "bf16":
        return api.mm_bf16_batch_invariant(a,b,out=output,chunks=1)
    fmt=api.fp4_format_for(a.device,True,b.shape[1],2*a.shape[1],None)
    return api.mm_fp4_batch_invariant(a,b,sfa,sfb,alpha,out=output,chunks=1,in_fmt=fmt)
