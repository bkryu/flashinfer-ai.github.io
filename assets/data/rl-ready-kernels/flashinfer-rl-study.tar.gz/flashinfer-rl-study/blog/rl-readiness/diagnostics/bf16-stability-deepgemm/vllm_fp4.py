"""Minimal binding of vLLM's unchanged CUTLASS W4A4 kernel and its pinned dependency."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

import torch
from torch.utils.cpp_extension import load

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]


def build_and_load():
    if os.environ.get("VLLM_BATCH_INVARIANT") != "1":
        raise RuntimeError("Set VLLM_BATCH_INVARIANT=1 before loading the kernel")
    cutlass = HERE / "cutlass-vllm"
    kernel = WORKSPACE / "vllm/csrc/quantization/fp4/nvfp4_scaled_mm_kernels.cu"
    binding = HERE / "vllm_fp4_binding.cpp"
    flags = ["-O3", "-std=c++20", "--expt-relaxed-constexpr",
             "--expt-extended-lambda", "-DENABLE_NVFP4_SM100=1", "-DUSE_CUDA",
             "-gencode=arch=compute_100f,code=sm_100f"]
    library = load(
        name="rl_blog_vllm_fp4",
        sources=[str(binding), str(kernel)],
        extra_include_paths=[str(WORKSPACE / "vllm/csrc"),
                             str(cutlass / "include"), str(cutlass / "tools/util/include"),
                             str(WORKSPACE / "flashinfer/3rdparty/cccl/libcudacxx/include"),
                             str(WORKSPACE / "flashinfer/3rdparty/cccl/cub"),
                             str(WORKSPACE / "flashinfer/3rdparty/cccl/thrust")],
        extra_cflags=["-O3", "-std=c++20"],
        extra_cuda_cflags=flags,
        is_python_module=False,
        verbose=True,
    )
    provenance = {
        "kernel": str(kernel),
        "kernel_sha256": hashlib.sha256(kernel.read_bytes()).hexdigest(),
        "binding_sha256": hashlib.sha256(binding.read_bytes()).hexdigest(),
        "vllm_commit": subprocess.check_output(
            ["git", "-C", str(WORKSPACE / "vllm"), "rev-parse", "HEAD"], text=True).strip(),
        "cutlass_commit": subprocess.check_output(
            ["git", "-C", str(cutlass), "rev-parse", "HEAD"], text=True).strip(),
        "cuda_flags": flags,
        "library": str(library),
        "batch_invariant": True,
        "note": "Unchanged upstream CUDA source; registration-only adapter; no serving-engine timing.",
    }
    (HERE / "vllm-fp4-build.json").write_text(json.dumps(provenance, indent=2) + "\n")
    return provenance


def mm(a, b, sfa, sfb, alpha, out=None):
    if out is None:
        out = torch.empty((a.shape[0], b.shape[0]), device=a.device, dtype=torch.bfloat16)
    torch.ops.rl_blog_vllm.mm(out, a, b, sfa, sfb, alpha)
    return out


if __name__ == "__main__":
    print(json.dumps(build_and_load(), indent=2), flush=True)
