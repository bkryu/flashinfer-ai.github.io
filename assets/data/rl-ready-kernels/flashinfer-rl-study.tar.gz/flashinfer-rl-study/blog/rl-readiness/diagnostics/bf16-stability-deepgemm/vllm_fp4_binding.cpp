#include <torch/csrc/stable/library.h>
#include <torch/csrc/stable/tensor.h>

// Bind the unchanged upstream entry, without installing the serving engine.
void cutlass_scaled_fp4_mm_sm100a(
    torch::stable::Tensor& out, const torch::stable::Tensor& a,
    const torch::stable::Tensor& b, const torch::stable::Tensor& a_sf,
    const torch::stable::Tensor& b_sf, const torch::stable::Tensor& alpha);

STABLE_TORCH_LIBRARY(rl_blog_vllm, ops) {
  ops.def("mm(Tensor! out, Tensor a, Tensor b, Tensor a_sf, Tensor b_sf, Tensor alpha) -> ()");
}

STABLE_TORCH_LIBRARY_IMPL(rl_blog_vllm, CUDA, ops) {
  ops.impl("mm", TORCH_BOX(&cutlass_scaled_fp4_mm_sm100a));
}
