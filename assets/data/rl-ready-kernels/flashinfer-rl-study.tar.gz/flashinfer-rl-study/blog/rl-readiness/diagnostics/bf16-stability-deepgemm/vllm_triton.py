"""Load unchanged vLLM BF16 Triton functions without serving-engine dependencies.

Only platform queries are adapted; kernel, wrapper, and shape tables are upstream.
"""

import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import typing

import torch
import triton
import triton.language as tl

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]


class PlatformQueries:
    def is_cuda(self):
        return True

    def is_cuda_alike(self):
        return True

    def get_device_capability(self):
        major, minor = torch.cuda.get_device_capability()
        return SimpleNamespace(major=major, minor=minor)


def load():
    config_path = WORKSPACE / "vllm/vllm/model_executor/determinism/batch_invariant_configs.py"
    source_path = WORKSPACE / "vllm/vllm/model_executor/determinism/batch_invariant.py"
    namespace = {"__name__": "rl_blog_vllm_triton_configs", "__file__": str(config_path),
                 "current_platform":PlatformQueries(), "DeviceCapability":SimpleNamespace}
    tree = ast.parse(config_path.read_text(), filename=str(config_path))
    tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and (n.module or "").startswith("vllm"))]
    exec(compile(tree, str(config_path), "exec"), namespace)
    names = {"_matmul_launch_metadata", "_compute_pid", "matmul_kernel_persistent", "matmul_persistent", "_resolve_block_sizes"}
    kernels = ast.parse(source_path.read_text(), filename=str(source_path))
    kernels.body = [n for n in kernels.body if isinstance(n, ast.FunctionDef) and n.name in names]
    ns = {"__name__":"rl_blog_vllm_triton", "__file__":str(source_path),
          "torch":torch, "triton":triton, "tl":tl, "Callable":typing.Callable,
          "Any":typing.Any, "current_platform":PlatformQueries(), "_BLOCK_SIZES_RESOLVED":False,
          "_get_matmul_config":namespace["_get_matmul_config"],
          "num_compute_units":lambda index:torch.cuda.get_device_properties(index).multi_processor_count,
          "get_max_shared_memory_bytes":lambda:torch.cuda.get_device_properties(0).shared_memory_per_block_optin}
    exec(compile(kernels, str(source_path), "exec"), ns)
    provenance = {"kernel_source":str(source_path), "kernel_sha256":hashlib.sha256(source_path.read_bytes()).hexdigest(),
                  "config_source":str(config_path), "config_sha256":hashlib.sha256(config_path.read_bytes()).hexdigest(),
                  "functions":sorted(names), "adaptation":"Platform queries only; unchanged AST function bodies and upstream shape tables",
                  "scope":"Direct persistent Triton reference, not vLLM default Rubin BF16 dispatch"}
    (HERE/"vllm-triton-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")
    return ns["matmul_persistent"]
