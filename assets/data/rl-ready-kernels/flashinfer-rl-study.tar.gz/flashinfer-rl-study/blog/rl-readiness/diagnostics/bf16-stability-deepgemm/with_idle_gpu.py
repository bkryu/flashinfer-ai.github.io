"""Launch on physical GPU 2 or 3 only, after exclusive locking and idle checks."""

import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", type=int, choices=(2, 3), required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command[:1] == ["--"]:
        command = command[1:]
    if not command:
        parser.error("a command is required after --")
    workspace = Path(__file__).resolve().parents[2]
    lock_path = workspace / ".gpu-locks" / f"gpu{args.gpu}.lock"
    with lock_path.open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit(f"GPU {args.gpu} is reserved; no command launched")
        samples = []
        for index in range(3):
            row = subprocess.check_output(
                ["nvidia-smi", "-i", str(args.gpu),
                 "--query-gpu=uuid,utilization.gpu,memory.used,clocks.sm,temperature.gpu",
                 "--format=csv,noheader,nounits"], text=True
            ).strip()
            uuid, util, memory, clock, temperature = [v.strip() for v in row.split(",")]
            processes = subprocess.check_output(
                ["nvidia-smi", "-i", str(args.gpu),
                 "--query-compute-apps=pid,used_memory", "--format=csv,noheader,nounits"],
                text=True,
            ).strip()
            sample = {"uuid": uuid, "utilization": int(util), "memory_mib": int(memory),
                      "clock_mhz": int(clock), "temperature_c": float(temperature),
                      "processes": processes}
            samples.append(sample)
            if int(util) != 0 or int(memory) > 16 or processes:
                raise SystemExit(f"GPU {args.gpu} is not free; no command launched: {sample}")
            if index < 2:
                time.sleep(1)
        print(json.dumps({"launch_utc": datetime.now(timezone.utc).isoformat(),
                          "physical_gpu": args.gpu, "idle_checks": samples}), flush=True)
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu),
                   RLK_GPUS="2 3", RLK_PERF_GPUS="2 3")
        result = subprocess.run(command, env=env)
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
