"""Archive only complete, publication-selected datasets; preserve local history."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
SCRIPTS = ["README.md", "REPRODUCING.md", "benchmark_gemm.py", "with_idle_gpu.py",
           "reproduce.py", "run_study.sh", "analyze_results.py", "backend_metadata.py", "audit_results.py", "audit_round_sensitivity.py", "plot_overview.py", "plot_ablation.py", "map_classes.py", "update_draft_results.py", "probe_round_stability.py", "prepare_review.py", "prepare_site_branch.py",
           "package_reproducer.py", "vllm_fp4.py", "vllm_fp4_binding.cpp", "vllm_triton.py",
           "probe_torch_narrow.py",
           "splitk_ablation.py", "deepgemm_bf16.py", "deepgemm_nvcc_compat.py", "build_deepgemm.sh", "deepgemm-build-manifest.json",
           "vllm-fp4-build.json", "vllm-triton-provenance.json", "cupti-smoke.json",
           "2026-11-11-rl-ready-kernels.md"]
ALLOWED = {"flashinfer_bi", "flashinfer_cutlass", "flashinfer_bf16_cute_dsl",
           "flashinfer_cute_dsl", "flashinfer_cudnn", "flashinfer_cutile",
           "torch_inductor_bi_triton", "vllm_triton_bi", "vllm_cutlass_bi_w4a4",
           "flashinfer_unsplit_ablation", "deepgemm_bf16_bi"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis", type=Path)
    args = parser.parse_args()
    summary = json.loads((args.analysis / "summary.json").read_text())
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    bundle = HERE / "bundles" / stamp
    root = bundle / "flashinfer-rl-study" / "blog" / "rl-readiness"
    root.mkdir(parents=True)
    for name in SCRIPTS:
        shutil.copy2(HERE/name, root/name)
    for name, values in summary.items():
        src = HERE/"results"/name
        manifest = values["manifest"]
        if not manifest.get("complete") or manifest.get("torch_dynamic_shapes"):
            raise RuntimeError(f"Inadmissible publication dataset: {name}")
        measured = hashlib.sha256((src/"harness.py").read_bytes()).hexdigest()
        if measured != manifest["harness_sha256"]:
            raise RuntimeError(f"Harness hash mismatch: {name}")
        rows = [json.loads(s) for s in (src/"samples.jsonl").read_text().splitlines()]
        if {r["backend"] for r in rows} - ALLOWED:
            raise RuntimeError(f"Unexpected publication backend in {name}")
        target = root/"results"/name
        target.mkdir(parents=True)
        for path in src.iterdir():
            if path.is_file() and path.suffix in {".py", ".cpp", ".txt", ".json", ".jsonl"}:
                shutil.copy2(path,target/path.name)
            if path.is_dir() and path.name=="deepgemm-generated":
                shutil.copytree(path,target/path.name)
        log = HERE/"logs"/f"{name}.log"
        if log.exists():
            (root/"logs").mkdir(exist_ok=True)
            shutil.copyfile(log,root/"logs"/log.name)
    (root/"analysis").mkdir()
    for path in args.analysis.iterdir():
        if path.is_file():
            shutil.copyfile(path,root/"analysis"/path.name)
    image_dir=root/"assets/imgs/rl-ready-kernels"
    image_dir.parent.mkdir(parents=True)
    shutil.copytree(HERE/"assets/imgs/rl-ready-kernels",image_dir)
    shutil.copytree(HERE/"class-map-v2", root/"class-map")
    for name in ("deepgemm-build.log","deepgemm-build-v2.log","deepgemm-build-v3.log","deepgemm-compat-compiles.jsonl"):
        path=HERE/"logs"/name
        if path.exists():
            (root/"logs").mkdir(exist_ok=True)
            shutil.copy2(path,root/"logs"/name)
    diagnostic = HERE/"results/torch-narrow-bitwise-diagnostic"
    if diagnostic.exists():
        shutil.copytree(diagnostic,root/"diagnostics/torch-narrow-bitwise")
    for name in ("bf16-stability-fi","bf16-stability-deepgemm"):
        source=HERE/"results"/name
        if source.exists():
            assert json.loads((source/"manifest.json").read_text()).get("complete")
            shutil.copytree(source,root/"diagnostics"/name)
    # Assets from exploratory datasets stay local, outside the publication bundle.
    allowed_assets = {f"{name}.svg" for name in summary} | {
        "canonical-dataflow.svg", "bf16-overview.svg", "nvfp4-overview.svg", "class-regions.svg", "splitk-ablation.svg"}
    allowed_assets |= {Path(name).with_suffix(".png").name for name in list(allowed_assets)}
    for path in (root/"assets/imgs/rl-ready-kernels").iterdir():
        if path.name not in allowed_assets:
            path.unlink()
    archive_root = bundle/"flashinfer-rl-study"
    checksums = []
    for path in sorted(archive_root.rglob("*")):
        if path.is_file():
            checksums.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(archive_root)}")
    (archive_root/"SHA256SUMS").write_text("\n".join(checksums)+"\n")
    archive_path = bundle/"flashinfer-rl-study.tar.gz"
    with tarfile.open(archive_path,"w:gz") as archive:
        archive.add(archive_root,arcname="flashinfer-rl-study")
    digest=hashlib.sha256(archive_path.read_bytes()).hexdigest()
    (bundle/"archive.sha256").write_text(f"{digest}  {archive_path.name}\n")
    public=HERE/"assets/data/rl-ready-kernels"
    public.mkdir(parents=True,exist_ok=True)
    shutil.copy2(archive_path,public/archive_path.name)
    shutil.copy2(bundle/"archive.sha256",public/"SHA256SUMS")
    print(json.dumps({"archive":str(archive_path),"sha256":digest,
                      "datasets":list(summary),"files":len(checksums)},indent=2))


if __name__=="__main__":
    main()
