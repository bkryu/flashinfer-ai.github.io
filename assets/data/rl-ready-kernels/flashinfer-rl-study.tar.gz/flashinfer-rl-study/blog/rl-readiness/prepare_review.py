"""Normalize local image links and generate an offline HTML reading copy."""
import argparse
import base64
from html import escape, unescape
from pathlib import Path
import re
import shutil

from markdown_it import MarkdownIt
import yaml

HERE=Path(__file__).resolve().parent
POST="2026-11-11-rl-ready-kernels.md"


def normalize_figures(text):
    def replace(match):
        figure=match.group(0)
        img=re.search(r'<img\s+src="([^"]+)"\s+alt="([^"]*)"',figure)
        if not img:
            raise ValueError("Figure has no image")
        src,alt=img.groups()
        src=src.lstrip("/")
        src=str(Path(src).with_suffix(".png"))
        caption=re.search(r"<figcaption>(.*?)</figcaption>",figure,re.S)
        result=f"![{unescape(alt)}]({src})"
        if caption:
            result+="\n\n*"+unescape(caption.group(1).strip())+"*"
        return "\n"+result+"\n"
    text=re.sub(r"<figure>.*?</figure>",replace,text,flags=re.S)
    text=text.replace("<details>",'<details markdown="1">')
    text=re.sub(r"</summary>\s*", "</summary>\n\n",text)
    text=re.sub(r"\s*</details>","\n\n</details>",text)
    # Local file viewers resolve assets beside the Markdown file.
    text=text.replace("](/assets/", "](assets/")
    return text


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--analysis",type=Path,default=HERE/"analysis-final")
    args=parser.parse_args()
    post=HERE/POST
    text=normalize_figures(post.read_text())
    assets=HERE/"assets/imgs/rl-ready-kernels"
    for name in re.findall(r"!\[[^\]]*\]\((assets/[^)]+\.png)\)",text):
        target=HERE/name
        if not target.exists():
            source=(HERE/"class-map-v2/class-regions.png" if target.stem=="class-regions"
                    else args.analysis/target.name)
            if not source.is_file():
                raise FileNotFoundError(source)
            shutil.copy2(source,target)
    post.write_text(text)
    _,frontmatter,body=text.split("---",2)
    meta=yaml.safe_load(frontmatter)
    renderer=MarkdownIt("commonmark",{"html":True}).enable("table")
    rendered=renderer.render(body)
    count=0
    def embed(match):
        nonlocal count
        path=HERE/unescape(match.group(1))
        if not path.is_file():
            raise FileNotFoundError(path)
        count+=1
        return 'src="data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()+'"'
    rendered=re.sub(r'src="(assets/[^\"]+\.png)"',embed,rendered)
    css="""
    body{max-width:1100px;margin:48px auto;padding:0 24px;color:#202722;font:18px/1.75 Georgia,serif}
    h1,h2,h3,summary,th{font-family:system-ui,sans-serif;line-height:1.3}h1{font-size:2.25em}
    h2{margin-top:2.2em}h3{margin-top:1.7em}a{color:#3f7415}img{display:block;width:100%;height:auto;margin:24px auto}
    table{display:block;overflow-x:auto;border-collapse:collapse;max-width:100%;font:14px/1.5 system-ui,sans-serif;margin:24px 0}
    th,td{padding:9px 12px;border:1px solid #dbe1d7;text-align:left}thead{background:#eff5e9}
    pre{padding:18px;overflow:auto;background:#f4f6f1;border-radius:5px;font-size:14px}code{font-size:.88em}
    details{margin:24px 0;padding:16px;border:1px solid #dbe1d7}summary{cursor:pointer;font-size:16px}
    .byline{font:15px system-ui,sans-serif;color:#60705a;margin-bottom:40px}
    """
    html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    html+=f'<title>{escape(meta["title"])}</title><style>{css}</style></head><body>'
    html+=f'<h1>{escape(meta["title"])}</h1><p class="byline">{escape(meta["author"])} · Review draft</p>'
    html+=rendered+"</body></html>"
    (HERE/"preview.html").write_text(html)
    print(f"Prepared local Markdown and offline HTML with {count} embedded figures")


if __name__=="__main__":
    main()
