"""Stage website-ready post/assets plus a GitHub-readable branch review copy."""
import argparse
from pathlib import Path
import re
import shutil

HERE=Path(__file__).resolve().parent
POST="2026-11-11-rl-ready-kernels.md"


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--site",type=Path,default=HERE/"site-reference")
    args=parser.parse_args()
    site=args.site.resolve()
    text=(HERE/POST).read_text()
    # Publication uses root-relative vector assets, independent of post URL.
    published=re.sub(r'(!\[[^\]]*\]\()assets/(.*?\.png)(\))',
                     lambda m:m[1]+"/assets/"+str(Path(m[2]).with_suffix(".svg"))+m[3],text)
    published=published.replace("](assets/", "](/assets/")
    (site/"_posts"/POST).write_text(published)
    # GitHub's source renderer resolves these relative to scripts/rl-readiness/.
    _,frontmatter,body=text.split("---",2)
    title=re.search(r'^title:\s*"(.*)"\s*$',frontmatter,re.M).group(1)
    review=site/"scripts/rl-readiness"
    review.mkdir(parents=True,exist_ok=True)
    header=f"# {title}\n\nBrian K. Ryu\n\n"
    header+=f"Reading copy with working figures. [Website post](../../_posts/{POST}) · [Performance tables](performance-tables.md) · [Reproduction guide](REPRODUCING.md)\n\n"
    header+="The post and this reading copy contain the same article; their asset paths differ for Jekyll and GitHub.\n\n"
    body=body.replace("](assets/", "](../../assets/")
    (review/"README.md").write_text(header+body.lstrip())
    shutil.copy2(HERE/"analysis-final/results.md",review/"performance-tables.md")
    report=review/"performance-tables.md"
    report.write_text(report.read_text().rstrip()+"\n")
    shutil.copy2(HERE/"REPRODUCING.md",review/"REPRODUCING.md")
    names=set(re.findall(r'!\[[^\]]*\]\((assets/[^)]+\.png)\)',text))
    for name in names:
        for source in [HERE/name,(HERE/name).with_suffix(".svg")]:
            target=site/source.relative_to(HERE)
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(source,target)
            if target.suffix==".svg":
                target.write_text("\n".join(line.rstrip() for line in source.read_text().splitlines()).rstrip()+"\n")
    data=site/"assets/data/rl-ready-kernels"
    data.mkdir(parents=True,exist_ok=True)
    for name in ("flashinfer-rl-study.tar.gz","SHA256SUMS"):
        shutil.copy2(HERE/"assets/data/rl-ready-kernels"/name,data/name)
    shutil.copy2(HERE/"analysis-final/latency.csv",data/"latency.csv")
    csv_path=data/"latency.csv"
    csv_path.write_bytes(csv_path.read_bytes().replace(b"\r\n",b"\n"))
    print(f"Prepared {site}: post, GitHub reading copy, {len(names)} figure pairs, tables, and reproduction bundle")


if __name__=="__main__":
    main()
