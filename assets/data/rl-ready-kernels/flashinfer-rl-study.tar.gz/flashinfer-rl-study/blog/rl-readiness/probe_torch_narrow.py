"""Record an out-of-primary-matrix Inductor bitwise diagnostic, no timings."""
import hashlib
import json
import os
from pathlib import Path
import sys
from unittest import mock

import torch
from torch._inductor.graph import GraphLowering

out=Path(sys.argv[1])
if os.environ.get("CUDA_VISIBLE_DEVICES") not in ("2","3"):
    raise SystemExit("Use with_idle_gpu.py on GPU 2 or 3")
out.mkdir(parents=True,exist_ok=True)
torch.manual_seed(20261111)
a=torch.randn(8192,8192,device="cuda",dtype=torch.bfloat16)
w=torch.randn(128,8192,device="cuda",dtype=torch.bfloat16)
records=[]
for mode in ("unprofiled","autotuned"):
    source_files=[]
    def save_source(source):
        path=out/f"{mode}-source-{len(source_files)}.py"
        path.write_text(source)
        source_files.append({"file":path.name,"sha256":hashlib.sha256(source.encode()).hexdigest()})
    options={"batch_invariant":True,"max_autotune":True,"max_autotune_gemm_backends":"TRITON",
             "autotune_fallback_to_aten":False,"deterministic":mode=="unprofiled"}
    torch._dynamo.reset()
    fn=torch.compile(torch.mm,fullgraph=True,dynamic=False,options=options)
    with mock.patch.object(GraphLowering,"save_output_code",save_source):
        full=fn(a,w.T).clone()
        small=fn(a[:129],w.T).clone()
    unequal=small.view(torch.int16)!=full[:129].view(torch.int16)
    coords=unequal.nonzero()[:8].cpu().tolist()
    records.append({"mode":mode,"options":options,"N":128,"K":8192,"M_reference":8192,"M_test":129,
                    "unequal_count":unequal.sum().item(),"max_abs_difference":(small-full[:129]).abs().max().item(),
                    "examples":[{"index":[i,j],"full_bits":full[i,j].view(torch.int16).item(),
                                 "small_bits":small[i,j].view(torch.int16).item()} for i,j in coords],
                    "sources":source_files,"torch":torch.__version__,"physical_gpu":os.environ["CUDA_VISIBLE_DEVICES"]})
(out/"diagnostic.json").write_text(json.dumps(records,indent=2)+"\n")
print(json.dumps(records,indent=2))
