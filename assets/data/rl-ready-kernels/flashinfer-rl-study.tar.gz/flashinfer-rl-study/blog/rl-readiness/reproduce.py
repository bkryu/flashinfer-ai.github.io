"""Replay a dataset's exact harness snapshot, after GPU admission by the wrapper."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    dataset = args.dataset.resolve()
    if os.environ.get("CUDA_VISIBLE_DEVICES") not in ("2", "3"):
        raise SystemExit("Launch this reproducer through with_idle_gpu.py on GPU 2 or 3")
    if (args.out / "samples.jsonl").exists():
        raise SystemExit("Choose a fresh output directory")
    manifest = json.loads((dataset / "manifest.json").read_text())
    snapshot = dataset / "harness.py"
    if hashlib.sha256(snapshot.read_bytes()).hexdigest() != manifest["harness_sha256"]:
        raise SystemExit("Harness snapshot hash does not match the measured manifest")
    for filename,expected in manifest.get("helper_sha256",{}).items():
        if hashlib.sha256((dataset/filename).read_bytes()).hexdigest()!=expected:
            raise SystemExit(f"Helper hash mismatch: {filename}")
    if manifest.get("bf16_deepgemm"):
        os.environ["DG_JIT_NVCC_COMPILER"]=str(dataset/"deepgemm_nvcc_compat.py")
        os.environ["DG_COMPAT_COMPILE_LOG"]=str(args.out.resolve()/"deepgemm-compiler-invocations.jsonl")
        provenance=json.loads((dataset/"deepgemm-provenance.json").read_text())
        for name,relative in [("deepgemm","."),("cutlass","third-party/cutlass"),("deepjit","third-party/deep_jit")]:
            path=HERE/"deepgemm-source"/relative
            actual=subprocess.check_output(["git","-C",str(path),"rev-parse","HEAD"],text=True).strip()
            if actual!=provenance["commits"][name]:
                raise SystemExit(f"DeepGEMM dependency differs: {name}")
    for key, path in [("flashinfer_commit", WORKSPACE / "flashinfer"),
                      ("vllm_commit", WORKSPACE / "vllm")]:
        actual = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()
        if actual != manifest[key]:
            raise SystemExit(f"{key} differs: {actual} != {manifest[key]}")
    sys.path[:0] = [str(WORKSPACE / "flashinfer"), str(HERE)]
    ns = runpy.run_path(str(snapshot), run_name="measured_harness")
    fn = ns["main"]
    # Import the measured adapter snapshots, with only dependency locations
    # rebound to this workspace. The harness copies those same files onward.
    for name in ("vllm_fp4", "vllm_triton", "splitk_ablation", "deepgemm_bf16"):
        helper = dataset / f"{name}.py"
        if not helper.exists():
            continue
        expected = manifest.get("helper_sha256", {}).get(helper.name)
        if expected and hashlib.sha256(helper.read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Adapter snapshot hash mismatch: {helper}")
        spec = importlib.util.spec_from_file_location(name, helper)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.HERE = HERE
        module.WORKSPACE = WORKSPACE
        sys.modules[name] = module
    fn.__globals__["HERE"] = dataset
    fn.__globals__["WORKSPACE"] = WORKSPACE
    fn.__globals__["SHAPES"] = [tuple(x) for x in manifest["shapes_nk"]]
    fn.__globals__["TOKENS"] = manifest["tokens"]
    if manifest.get("splitk_ablation"):
        fn.__globals__["ABLATION_SHAPES"] = [tuple(x) for x in manifest["shapes_nk"]]
    sys.argv = [str(snapshot), "--dtype", manifest["dtype"], "--out", str(args.out),
                "--rounds", str(manifest["rounds"]), "--repeats", str(manifest["repeat_iters"])]
    if manifest["fi_autotuned"]:
        sys.argv += ["--fi-tune"]
    if manifest.get("bf16_extra"):
        sys.argv += ["--bf16-extra"]
    if manifest.get("bf16_libraries"):
        sys.argv += ["--bf16-libraries"]
    if manifest.get("fi_only"):
        sys.argv += ["--fi-only"]
    if manifest.get("splitk_ablation"):
        sys.argv += ["--splitk-ablation", "--tokens", ",".join(map(str,manifest["tokens"]))]
    if manifest.get("bf16_deepgemm"):
        sys.argv += ["--bf16-deepgemm"]
    if manifest.get("torch_dynamic_shapes"):
        sys.argv += ["--torch-dynamic"]
    if manifest.get("torch_options", {}) and manifest["torch_options"].get("deterministic"):
        sys.argv += ["--torch-untuned"]
    if manifest["shapes_nk"] == ns["DIAGNOSTICS"] or manifest["shapes_nk"] == [list(x) for x in ns["DIAGNOSTICS"]]:
        sys.argv += ["--diagnostics"]
    fn()


if __name__ == "__main__":
    main()
