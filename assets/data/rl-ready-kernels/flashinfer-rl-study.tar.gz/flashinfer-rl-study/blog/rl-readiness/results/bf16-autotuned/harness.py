"""Cold-L2 CUPTI GEMM study on NVIDIA Vera Rubin NVL4.

Use with_idle_gpu.py to reserve physical GPU 2 or 3 before running this script.
Compilation, correctness, quantization, and weight preparation are outside timing.
"""

import argparse
from contextlib import nullcontext
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import shutil
import sys
import time
import warnings
from unittest import mock

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
sys.path.insert(0, str(WORKSPACE / "flashinfer"))

import torch
import flashinfer
import pynvml
from flashinfer.testing import bench_gpu_time

SHAPES = [(4096, 4096), (6144, 4096), (14336, 4096), (4096, 14336),
          (8192, 8192), (28672, 8192), (8192, 28672), (1024, 28672)]
DIAGNOSTICS = [(128, 8192), (256, 16384), (512, 28672)]
TOKENS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192]
BOUNDARIES = [15, 17, 31, 33, 63, 65, 127, 129, 1023, 1025]
TORCH_OPTIONS = {"batch_invariant": True, "max_autotune": True,
                 "max_autotune_gemm_backends": "TRITON", "autotune_fallback_to_aten": False}


def commit(path):
    return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()


def telemetry():
    # UUID is resolved through the single visible logical device, never GPU 0/1.
    physical = os.environ["CUDA_VISIBLE_DEVICES"]
    if not hasattr(telemetry, "handle"):
        pynvml.nvmlInit()
        telemetry.handle = pynvml.nvmlDeviceGetHandleByIndex(int(physical))
    handle = telemetry.handle
    uuid = pynvml.nvmlDeviceGetUUID(handle)
    if isinstance(uuid, bytes):
        uuid = uuid.decode()
    return ", ".join(map(str, [uuid,
        pynvml.nvmlDeviceGetClockInfo(handle, pynvml.NVML_CLOCK_SM),
        pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU),
        pynvml.nvmlDeviceGetPowerUsage(handle) / 1000,
        pynvml.nvmlDeviceGetUtilizationRates(handle).gpu,
        round(pynvml.nvmlDeviceGetMemoryInfo(handle).used / 2**20)]))


def bits_equal(a, b):
    return torch.equal(a.view(torch.int16), b.view(torch.int16))


def fp4_dequant_rows(packed, sf, rows, k):
    """Small CPU reference slice of the shared 128x4 scale layout."""
    row_ids = torch.tensor(rows, device=packed.device, dtype=torch.long).view(-1, 1)
    blocks = torch.arange(k // 16, device=packed.device).view(1, -1)
    kt = (k // 16 + 3) // 4
    offsets = ((row_ids // 128) * kt * 512 + (blocks // 4) * 512
               + (row_ids % 32) * 16 + ((row_ids % 128) // 32) * 4 + blocks % 4)
    scales = sf.view(-1).view(torch.uint8)[offsets].cpu().view(torch.float8_e4m3fn).double()
    codes = packed[rows].cpu().to(torch.long)
    unpacked = torch.stack((codes & 15, codes >> 4), dim=-1).reshape(len(rows), k)
    values = torch.tensor([0, .5, 1, 1.5, 2, 3, 4, 6, -0., -.5, -1, -1.5, -2, -3, -4, -6],
                          dtype=torch.float64)
    return values[unpacked] * scales.repeat_interleave(16, dim=1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dtype", choices=("bf16", "nvfp4"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--repeats", type=int, default=50)
    parser.add_argument("--diagnostics", action="store_true")
    parser.add_argument("--fi-tune", action="store_true")
    parser.add_argument("--torch-dynamic", action="store_true")
    parser.add_argument("--torch-untuned", action="store_true")
    parser.add_argument("--tokens", help="Optional comma-separated M values for a supplemental sweep")
    parser.add_argument("--bf16-extra", action="store_true")
    args = parser.parse_args()
    if os.environ.get("CUDA_VISIBLE_DEVICES") not in ("2", "3"):
        raise SystemExit("This study is restricted to a single physical GPU 2 or 3")
    from cupti import cupti  # require CUPTI rather than accepting event fallback
    del cupti
    args.out.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(__file__, args.out / "harness.py")
    for filename in ("with_idle_gpu.py", "vllm_fp4.py", "vllm_fp4_binding.cpp", "vllm_triton.py"):
        shutil.copyfile(HERE / filename, args.out / filename)
    (args.out / "pip-freeze.txt").write_text(subprocess.check_output(
        [sys.executable, "-m", "pip", "freeze"], text=True))
    torch._dynamo.config.recompile_limit = 256
    torch._dynamo.config.accumulated_recompile_limit = 1024
    torch.manual_seed(20261111)
    props = torch.cuda.get_device_properties(0)
    shapes = (DIAGNOSTICS if args.diagnostics else SHAPES)
    torch_options = dict(TORCH_OPTIONS)
    if args.torch_untuned:
        # The deterministic selector picks an admitted Triton candidate without
        # GPU profiling; max_autotune=False would otherwise select ATen GEMM.
        torch_options["deterministic"] = True
    tokens = TOKENS
    if args.tokens:
        tokens = sorted({int(m) for m in args.tokens.split(",")})
        if not tokens or min(tokens) < 1:
            raise ValueError("Token counts must be positive")
    if args.pilot:
        shapes = [SHAPES[0], DIAGNOSTICS[0]]
        tokens = [1, 16, 128, 1024]
    manifest = {"hardware_name": "NVIDIA Vera Rubin NVL4", "compute_capability": [10, 7],
                "gpu_uuid": str(props.uuid), "physical_gpu": os.environ["CUDA_VISIBLE_DEVICES"],
                "sm_count": props.multi_processor_count, "l2_bytes": props.L2_cache_size,
                "torch": torch.__version__, "torch_commit": torch.version.git_version,
                "flashinfer_commit": commit(WORKSPACE / "flashinfer"),
                "vllm_commit": commit(WORKSPACE / "vllm"),
                "cccl_commit": commit(WORKSPACE / "flashinfer/3rdparty/cccl"),
                "nvcc_version": subprocess.check_output([str(Path(os.environ["CUDA_HOME"]) / "bin/nvcc"), "--version"], text=True),
                "driver_version": subprocess.check_output(["nvidia-smi", "-i", os.environ["CUDA_VISIBLE_DEVICES"], "--query-gpu=driver_version", "--format=csv,noheader"], text=True).strip(),
                "flashinfer_module": flashinfer.__file__,
                "flashinfer_build_version": flashinfer.__version__,
                "cupti_python": importlib.metadata.version("cupti-python"),
                "cutlass_dsl": importlib.metadata.version("nvidia-cutlass-dsl"),
                "dtype": args.dtype, "fi_autotuned": args.fi_tune,
                "bf16_extra": args.bf16_extra,
                "torch_options": torch_options if args.dtype == "bf16" else None,
                "torch_dynamic_shapes": args.torch_dynamic,
                "shapes_nk": shapes, "tokens": tokens, "rounds": args.rounds,
                "warmup_iters": 10, "repeat_iters": args.repeats,
                "timing": "CUPTI first-to-last kernel span, cold L2, CUDA graph replay",
                "telemetry_backend": "NVML, explicitly indexed physical GPU 2 or 3",
                "nvfp4_boundary": "prequantized GEMM only; common packed codes/scales/alpha",
                "input_recipe": {"seed": 20261111, "per_shape_seed": "base_seed + shape_index",
                                 "source_distribution": "torch.randn BF16", "nvfp4_global_scale":256.0,
                                 "nvfp4_alpha":2.0**-16, "nvfp4_4over6":False},
                "start_utc": datetime.now(timezone.utc).isoformat(),
                "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    from flashinfer.batch_invariant import fingerprint
    manifest["class_fingerprints"] = {
        f"N={n},K={k}": fingerprint("mm_bf16", N=n, K=k) if args.dtype == "bf16"
        else fingerprint("mm_fp4", N=n, K=k, out_dtype=torch.bfloat16, use_nvfp4=True, arch=(10,7))
        for n,k in shapes
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    raw = (args.out / "samples.jsonl").open("a", buffering=1)
    checks = (args.out / "correctness.jsonl").open("a", buffering=1)
    sources = []
    if args.dtype == "nvfp4":
        from vllm_fp4 import build_and_load, mm as vllm_mm
        build_and_load()
    if args.bf16_extra:
        from vllm_triton import load
        vllm_bf16_mm = load()
    from torch._inductor.graph import GraphLowering

    def save_source(source):
        index = len(sources)
        if re.search(r"extern_kernels\.(mm|addmm|bmm)\s*\(", source):
            raise RuntimeError("Unexpected external ATen GEMM; excluded from publication")
        path = args.out / f"torch-generated-{index}.py"
        path.write_text(source)
        sources.append({"file": path.name, "sha256": hashlib.sha256(source.encode()).hexdigest()})

    for shape_index, (n, k) in enumerate(shapes):
        print(f"SETUP {args.dtype} N={n} K={k}", flush=True)
        torch.manual_seed(20261111 + shape_index)
        max_m = max(tokens)
        a = torch.randn(max_m, k, device="cuda", dtype=torch.bfloat16)
        w = torch.randn(n, k, device="cuda", dtype=torch.bfloat16)
        selected_cols = [0, n // 3, n // 2, n - 1]
        if args.dtype == "nvfp4":
            global_scale = torch.tensor([256.0], device="cuda", dtype=torch.float32)
            aq, sa = flashinfer.nvfp4_quantize(a, global_scale, backend="cuda", nvfp4_4over6=None)
            wq, sw = flashinfer.nvfp4_quantize(w, global_scale, backend="cuda", nvfp4_4over6=None)
            aq, wq = aq.view(torch.uint8), wq.view(torch.uint8)
            sa, sw = sa.view(torch.uint8).reshape(-1), sw.view(torch.uint8).reshape(-1)
            alpha = torch.tensor([2.0**-16], device="cuda", dtype=torch.float32)
            reference = (fp4_dequant_rows(aq, sa, [0, 1], k)
                         @ fp4_dequant_rows(wq, sw, selected_cols, k).T) * 2.0**-16
            del a, w
        else:
            reference = a[:2].cpu().double() @ w[selected_cols].cpu().double().T
            compiled = None if args.bf16_extra else torch.compile(torch.mm, fullgraph=True, dynamic=args.torch_dynamic, options=torch_options)
        full_outputs = {}
        check_tokens = sorted(set(tokens + [m for m in BOUNDARIES if m <= max_m]), reverse=True)
        for m in check_tokens:
            out = {name: torch.empty(m, n, device="cuda", dtype=torch.bfloat16)
                   for name in ("flashinfer_bi", "flashinfer_regular", "competitor")}
            if args.dtype == "bf16":
                x, weight = a[:m].contiguous(), w.T
                functions = {
                    "flashinfer_bi": lambda: flashinfer.mm_bf16(x, weight, out=out["flashinfer_bi"],
                                                              backend="auto", batch_invariant=True),
                    "flashinfer_cutlass": lambda: flashinfer.mm_bf16(x, weight, out=out["flashinfer_regular"],
                                                                    backend="cutlass"),
                    "torch_inductor_bi_triton": lambda: compiled(x, weight),
                }
                invariant_names = ("flashinfer_bi", "torch_inductor_bi_triton")
                if args.bf16_extra:
                    functions = {
                        "flashinfer_bi": functions["flashinfer_bi"],
                        "vllm_triton_bi": lambda: vllm_bf16_mm(x, weight),
                    }
                    if m <= 32:
                        functions["flashinfer_bf16_cute_dsl"] = lambda: flashinfer.mm_bf16(
                            x, weight, out=out["flashinfer_regular"], backend="cute-dsl")
                    else:
                        checks.write(json.dumps({"backend":"flashinfer_bf16_cute_dsl", "M":m,"N":n,"K":k,
                                                 "status":"unsupported", "reason":"Public backend requires M <= 32"})+"\n")
                    invariant_names = ("flashinfer_bi", "vllm_triton_bi")
            else:
                x = aq[:m].contiguous()
                sf_rows = (m + 127) // 128 * 128
                sf_k = (k // 16 + 3) // 4 * 4
                sx = sa[:sf_rows * sf_k]
                vsx = sx.view(torch.float8_e4m3fn).reshape(sf_rows, sf_k)
                vsw = sw.view(torch.float8_e4m3fn).reshape((n + 127) // 128 * 128, sf_k)
                functions = {
                    "flashinfer_bi": lambda: flashinfer.mm_fp4(x, wq.T, sx, sw, alpha,
                        out=out["flashinfer_bi"], backend="auto", batch_invariant=True, enable_pdl=False),
                    "flashinfer_cute_dsl": lambda: flashinfer.mm_fp4(x, wq.T, vsx, vsw.T, alpha,
                        out=out["flashinfer_regular"], backend="cute-dsl", enable_pdl=False),
                    "vllm_cutlass_bi_w4a4": lambda: vllm_mm(x, wq, vsx, vsw, alpha, out=out["competitor"]),
                }
                invariant_names = ("flashinfer_bi", "vllm_cutlass_bi_w4a4")
            for name, fn in functions.items():
                default_result = None
                if args.fi_tune and name == "flashinfer_bi":
                    from flashinfer.gemm.batch_invariant import api as direct
                    if args.dtype == "bf16":
                        default_result = direct.mm_bf16_batch_invariant(x, weight).clone()
                    else:
                        default_result = direct.mm_fp4_batch_invariant(x, wq.T, sx, sw, alpha).clone()
                context = mock.patch.object(GraphLowering, "save_output_code", save_source) if name.startswith("torch") else nullcontext()
                with context:
                    if args.fi_tune and name.startswith("flashinfer"):
                        tune_tokens = tuple(t for t in tokens if t <= 32) if name == "flashinfer_bf16_cute_dsl" else tuple(tokens)
                        with flashinfer.autotune(True, tuning_buckets=tune_tokens):
                            result = fn()
                    else:
                        result = fn()
                torch.cuda.synchronize()
                if default_result is not None and not bits_equal(result, default_result):
                    raise RuntimeError(f"Tuning changed invariant bits at {m,n,k}")
                if not torch.isfinite(result).all().item():
                    raise RuntimeError(f"Nonfinite output: {name} {m,n,k}")
                sample_rows = min(m, 2)
                error = (result[:sample_rows, selected_cols].cpu().double() - reference[:sample_rows]).abs().max().item()
                relative = error / max(reference[:sample_rows].abs().max().item(), 1e-6)
                if relative > .02:
                    raise RuntimeError(f"Accuracy failed {name} {m,n,k}: {relative}")
                bitwise = None
                if name in invariant_names:
                    if m == max_m:
                        full_outputs[name] = result.clone()
                    bitwise = bits_equal(result, full_outputs[name][:m])
                    snapshot = result.clone()
                    if not bitwise or not bits_equal(fn(), snapshot):
                        raise RuntimeError(f"Bitwise invariance failed {name} {m,n,k}")
                checks.write(json.dumps({"backend": name, "M": m, "N": n, "K": k,
                                         "relative_error": relative, "bitwise_equal": bitwise}) + "\n")
            if m not in tokens:
                continue
            # Establish active clocks before collecting a round; compilation remains excluded.
            until = time.monotonic() + .25
            while time.monotonic() < until:
                functions["flashinfer_bi"]()
            torch.cuda.synchronize()
            for round_index in range(args.rounds):
                names = list(functions)
                random.Random(20261111 + round_index + m).shuffle(names)
                for name in names:
                    before = telemetry()
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter("always")
                        samples = bench_gpu_time(functions[name], enable_cupti=True, cold_l2_cache=True,
                                                 use_cuda_graph=True, dry_run_iters=10, repeat_iters=args.repeats)
                    messages = [str(w.message) for w in caught]
                    if any("falling back" in msg.lower() for msg in messages):
                        raise RuntimeError(f"CUPTI fallback: {messages}")
                    record = {"backend": name, "dtype": args.dtype, "M": m, "N": n, "K": k,
                              "selection_mode": ("autotuned" if args.fi_tune else "untuned")
                                  if name.startswith("flashinfer") else
                                  (("unprofiled_deterministic_choice" if args.torch_untuned else "autotuned")
                                   if name.startswith("torch") else "fixed_invariant_configuration"),
                              "round": round_index, "samples_ms": samples,
                              "median_us": statistics.median(samples) * 1000,
                              "telemetry_before": before, "telemetry_after": telemetry(), "warnings": messages}
                    raw.write(json.dumps(record) + "\n")
            print(f"DONE {args.dtype} M={m} N={n} K={k}", flush=True)
        if sources:
            (args.out / "torch-source-manifest.json").write_text(json.dumps(sources, indent=2) + "\n")
        if args.dtype == "bf16" and not args.bf16_extra:
            permutation = torch.randperm(max_m, device="cuda")
            if not bits_equal(compiled(a[permutation], w.T),
                              full_outputs["torch_inductor_bi_triton"][permutation]):
                raise RuntimeError(f"PyTorch permutation invariance failed at {n,k}")
        del full_outputs, out
        if args.dtype == "nvfp4":
            del aq, wq, sa, sw
        else:
            del a, w, compiled
        torch.cuda.empty_cache()
    raw.close()
    checks.close()
    if args.fi_tune:
        with flashinfer.autotune(True, cache=str(args.out / "flashinfer-autotune.json")):
            pass
    manifest["complete"] = True
    manifest["end_utc"] = datetime.now(timezone.utc).isoformat()
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"COMPLETE {args.out}", flush=True)


if __name__ == "__main__":
    main()
